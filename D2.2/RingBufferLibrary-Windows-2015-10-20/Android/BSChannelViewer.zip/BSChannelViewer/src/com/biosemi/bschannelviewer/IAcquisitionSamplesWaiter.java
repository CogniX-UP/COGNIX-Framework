package com.biosemi.bschannelviewer;

public interface IAcquisitionSamplesWaiter
	{
	public void newAcquisitionSamples(int cycleNum, int seamIndex);
	}
