package com.biosemi.bschannelviewer;


import java.util.Set;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class AcquisitionControlActivity extends Activity
	{
	
	// variables that must be saved/restored when orientation changes 
	
	private int	showAbsChan;

	// other variables
	
    private static final String TAG = "AcquisitionControlActivity";
    private static final boolean D = true;
    private static final String	remoteAcquisitionFragmentTag="remoteAcquisition";

	boolean	acquisitionCancelled;
	private String	ipAddrString;
	private String	portString;

	public Handler	timeSamplingHandler;
	private RemoteAcquisitionFragment	remoteAcquisitionFragment;
	private Context	thisContext;
	private LeadOffsetByGraphView	leadOffsetByGraphView;
	private LeadOffsetByLayoutView	leadOffsetByLayoutView;
	private SingleLeadView	singleLeadView;
	private String	currentOffsetView;
	private Menu	optionsMenu;
	private boolean	suspendXfrUpdates;
	private PopupWindow	helpPopupWindow;

	@Override
	protected void onCreate(Bundle savedInstanceState)
		{
		super.onCreate(savedInstanceState);
	    getWindow().requestFeature(Window.FEATURE_ACTION_BAR);	// make sure there is an action bar
		// Show the Up button in the action bar.
		getActionBar().setDisplayHomeAsUpEnabled(true);

		Bundle bundle = this.getIntent().getExtras();
		ipAddrString = bundle.getString("ipAddrString");
		portString = bundle.getString("portString");
		if (D) Log.d(TAG, "onCreate bundle: ipAddr = "+ipAddrString+", port = "+portString);
		setTitle(ipAddrString+", port "+portString);

		int numChannelsToRequest = bundle.getInt("num_channels_to_request", 0);
		if (D) Log.d(TAG, "onCreate bundle: num_channels_to_request = "+numChannelsToRequest);

		thisContext = this;
		
		boolean verticalOrientation = false;
		if (getResources().getConfiguration().orientation ==  Configuration.ORIENTATION_PORTRAIT)
			verticalOrientation = true;

		if (verticalOrientation)
			setContentView(R.layout.activity_acquisition_control_v);
		else
			setContentView(R.layout.activity_acquisition_control_h);

	    acquisitionCancelled = false;
	    showAbsChan = 2;
	    currentOffsetView = "By Graph";
	    suspendXfrUpdates = false;

	    FragmentManager fragMgr = getFragmentManager();
		remoteAcquisitionFragment = (RemoteAcquisitionFragment)fragMgr.findFragmentByTag(remoteAcquisitionFragmentTag);
		if (remoteAcquisitionFragment == null)
			{	        	
			if (D) Log.d(TAG, "creating new RemoteAcquisitionFragment");
			remoteAcquisitionFragment = new RemoteAcquisitionFragment();

			Bundle argBundle = new Bundle();
			argBundle.putString("ipAddr", ipAddrString);
			argBundle.putString("port", portString);
			argBundle.putInt("num_channels_to_request", numChannelsToRequest);
			remoteAcquisitionFragment.setArguments(argBundle);
			
			FragmentTransaction fragXact = fragMgr.beginTransaction();
			fragXact.add(remoteAcquisitionFragment, remoteAcquisitionFragmentTag);		// no view
			fragXact.commit();
			}
		else
			if (D) Log.d(TAG, "RemoteAcquisitionFragment already exists");

        LinearLayout layout = new LinearLayout(this);
        layout.setId(999888);
        LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        layout.setLayoutParams(layoutParams);
        layout.setOrientation(LinearLayout.VERTICAL);

		// make sure any needed views are created
		
		if (currentOffsetView.equals("By Graph"))
			{
			leadOffsetByGraphView = new LeadOffsetByGraphView(getBaseContext(), remoteAcquisitionFragment, this, savedInstanceState);
			((LinearLayout)findViewById(R.id.acquisition_control_upper_composite)).addView(leadOffsetByGraphView);
			}

		if (currentOffsetView.equals("By Layout") || ((savedInstanceState != null) && savedInstanceState.containsKey("leadOffsetByLayoutViewActive")))
			{
			leadOffsetByLayoutView = new LeadOffsetByLayoutView(getBaseContext(), remoteAcquisitionFragment, this, savedInstanceState);
			((LinearLayout)findViewById(R.id.acquisition_control_upper_composite)).addView(leadOffsetByLayoutView);
			}

		// make sure the correct view is visible
		
		if (currentOffsetView.equals("By Graph"))
			{
			if (leadOffsetByLayoutView != null)							
				leadOffsetByLayoutView.setVisibility(View.GONE);							
			leadOffsetByGraphView.setVisibility(View.VISIBLE);
			}
		else
			{
			if (leadOffsetByGraphView != null)
				leadOffsetByGraphView.setVisibility(View.GONE);
			leadOffsetByLayoutView.setVisibility(View.VISIBLE);
			}

		singleLeadView = new SingleLeadView(thisContext, remoteAcquisitionFragment, this, savedInstanceState);

		((LinearLayout)findViewById(R.id.acquisition_control_lower_composite)).addView(singleLeadView);
	    
		int frameColor = Color.rgb(0x95, 0x8d, 0xb6);
		((LinearLayout)findViewById(R.id.acquisition_control_lower_composite)).setBackgroundColor(frameColor);
		}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
		{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_acquisition_control, menu);
		optionsMenu = menu;
	    return true;
		}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
		{
		switch (item.getItemId())
			{
			case android.R.id.home:
				// This ID represents the Home or Up button. In the case of this
				// activity, the Up button is shown. Use NavUtils to allow users
				// to navigate up one level in the application structure. For
				// more details, see the Navigation pattern on Android Design:
				//
				// http://developer.android.com/design/patterns/navigation.html#up-vs-back
				//
				if (singleLeadView != null)
					singleLeadView.requestStop();
    		
				if (remoteAcquisitionFragment != null)
					if (remoteAcquisitionFragment.isConnected())
    					{
						remoteAcquisitionFragment.disconnect();
						remoteAcquisitionFragment = null;
    					}
    		
				setResult(RESULT_OK, getIntent());
  
				System.exit(0);
				finish();
				return true;

    		case R.id.acquisition_help:
    			if (helpPopupWindow == null)
        			displayHelp(R.string.acquisition_control_help_strings);
        		else
        			{
        			helpPopupWindow.dismiss();
        			helpPopupWindow = null;
        			}
    			return true;

    		case R.id.acquisition_offset_by_graph:
    			if (!currentOffsetView.equals("By Graph"))
    				{
    				switchLeadOffsetView("By Graph");
    				}
    			return true;

    		case R.id.acquisition_offset_by_cap_layout:
    			if (!currentOffsetView.equals("By Layout"))
    				{
    				switchLeadOffsetView("By Layout");
    				}
    			return true;
    			
    		default:
    			return super.onOptionsItemSelected(item);
			}
		}
	
	public void cancelAcquisition()
		{
		acquisitionCancelled = true;

		if (singleLeadView != null)
			singleLeadView.requestStop();
	
		if (remoteAcquisitionFragment != null)
			if (remoteAcquisitionFragment.isConnected())
				{
				remoteAcquisitionFragment.disconnect();
				remoteAcquisitionFragment = null;
				}

		getIntent().putExtra("ERROR_MSG", "Cancelled by user");
		setResult(RESULT_CANCELED, getIntent());
		finish();
		}

	public void switchLeadOffsetView(String newView)
		{
		if (newView != null)
			{
			if ((currentOffsetView == null) || (newView.equals(currentOffsetView) == false))
				{
				if (currentOffsetView != null)
					{
					if (currentOffsetView.equals("By Graph"))
						leadOffsetByGraphView.setVisibility(View.GONE);
					else
						leadOffsetByLayoutView.setVisibility(View.GONE);
					currentOffsetView = null;
					}
				}
			
			if (currentOffsetView == null)
				{
				LinearLayout ll = ((LinearLayout)findViewById(R.id.acquisition_control_upper_composite));

				if (newView.equals("By Layout"))
					{
					if (leadOffsetByLayoutView == null)
						{
						leadOffsetByLayoutView = new LeadOffsetByLayoutView(getBaseContext(), remoteAcquisitionFragment, AcquisitionControlActivity.this, null);
						ll.addView(leadOffsetByLayoutView);
						}
					
					if (leadOffsetByLayoutView != null)
						leadOffsetByLayoutView.setVisibility(View.VISIBLE);
					currentOffsetView = "By Layout";
					
					if (optionsMenu != null)
						{
						optionsMenu.findItem(R.id.acquisition_offset_by_graph).setEnabled(true);			
						optionsMenu.findItem(R.id.acquisition_offset_by_cap_layout).setEnabled(false);
						}
					}
				else
					{
					if (leadOffsetByGraphView == null)
						{
						leadOffsetByGraphView = new LeadOffsetByGraphView(getBaseContext(), remoteAcquisitionFragment, AcquisitionControlActivity.this, null);
						ll.addView(leadOffsetByGraphView);
						}
					
					if (leadOffsetByGraphView != null)
						leadOffsetByGraphView.setVisibility(View.VISIBLE);
					
					currentOffsetView = "By Graph";
					if (optionsMenu != null)
						{
						optionsMenu.findItem(R.id.acquisition_offset_by_graph).setEnabled(false);			
						optionsMenu.findItem(R.id.acquisition_offset_by_cap_layout).setEnabled(true);
						}
					}
				}
			}
		}
	
	public void setChannelToPlot(int chanOffset)
	// chanOffset counts from 0
		{
		if (chanOffset != showAbsChan)
			{
			int remoteNumChannels = remoteAcquisitionFragment.getRemoteNumChannels();
			int remoteNumChannelsXfr = remoteAcquisitionFragment.getRemoteNumChannelsXfr();
			if (remoteNumChannelsXfr != remoteNumChannels)
				if (remoteAcquisitionFragment.isChannelValid(chanOffset) == false)
				{
				// change channels being transferred
				if ((chanOffset-2)/32 != (showAbsChan-2)/32)
					{
System.out.println("new transfer ranges required");
					int firstChan = 2 + ((chanOffset-2)/32)*32 + 1;
					int lastChan = firstChan + 31;
					if (lastChan > remoteNumChannels)
						lastChan = remoteNumChannels;
					
					int[] transferChannelRanges = new int[4];
					transferChannelRanges[0] = 1;
					transferChannelRanges[1] = 2;
					transferChannelRanges[2] = firstChan;
					transferChannelRanges[3] = lastChan;
					
					remoteAcquisitionFragment.setTransferChannelRequestRanges(2, transferChannelRanges);
					
					Toast toast = Toast.makeText(thisContext, "Requesting channels "+firstChan+"-"+lastChan+" from remote server", Toast.LENGTH_LONG);
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.show();
					}
				}
			
			showAbsChan = chanOffset;
		
			if (leadOffsetByGraphView != null)
				leadOffsetByGraphView.setChannelToPlot(chanOffset);

			if (leadOffsetByLayoutView != null)
				leadOffsetByLayoutView.setChannelToPlot(chanOffset);

			if (singleLeadView != null)
				singleLeadView.setChannelToPlot(chanOffset);
			}
		}
	
	public int getChannelToPlot()
		{// counting from 0
		return showAbsChan;
		}
	
	public boolean getAcquisitionCancelled()
		{
		return acquisitionCancelled;
		}

	@Override
	public void onSaveInstanceState(Bundle outState)
		{
		outState.putInt("showAbsChan",  showAbsChan);

		if (singleLeadView != null)
			{
			outState.putBoolean("singleLeadViewActive", true);
			singleLeadView.onSaveInstanceState(outState);
			}

		if (leadOffsetByGraphView != null)
			{
			outState.putBoolean("leadOffsetByGraphViewActive", true);
			leadOffsetByGraphView.onSaveInstanceState(outState);
			}

		if (leadOffsetByLayoutView != null)
			{
			outState.putBoolean("leadOffsetByLayoutViewActive", true);
			leadOffsetByLayoutView.onSaveInstanceState(outState);
			}
		
		if (currentOffsetView != null)
			outState.putString("currentOffsetView", currentOffsetView);
		
		outState.putBoolean("suspendXfrUpdates",  suspendXfrUpdates);
		
		super.onSaveInstanceState(outState);
		}
	
	@Override
	public void onRestoreInstanceState(Bundle inState)
		{
		super.onRestoreInstanceState(inState);
	
		if (inState != null)
			{
	   		Set<String> keys = inState.keySet();
		   		
	   		if (keys.contains("singleLeadViewActive"))
	   			singleLeadView.onRestoreInstanceState(inState);

	   		if (keys.contains("leadOffsetByGraphViewActive"))
	   			leadOffsetByGraphView.onRestoreInstanceState(inState);
	  		
	   		if (keys.contains("leadOffsetByLayoutViewActive"))
	   			leadOffsetByLayoutView.onRestoreInstanceState(inState);
			
	   		if (keys.contains("currentOffsetView"))
	   			{
				String offsetView = inState.getString("currentOffsetView");
				if ((currentOffsetView == null) || (offsetView.equals(currentOffsetView) == false))
					switchLeadOffsetView(offsetView);
	   			}
	   		
	   		if (keys.contains("showAbsChan"))
	   			{
	   			int chan = inState.getInt("showAbsChan");
	   			setChannelToPlot(chan);
	   			}
	   		
	   		if (keys.contains("suspendXfrUpdates"))
	   			{
	   			suspendXfrUpdates = inState.getBoolean("suspendXfrUpdates");
	   			
	   			if (suspendXfrUpdates == true)
	   				resumeXfrUpdates();
	   			}
	   		}
		}
	
	public void suspendXfrUpdates()
		{		
		suspendXfrUpdates = true;
		
		if (leadOffsetByGraphView != null)
			leadOffsetByGraphView.suspendXfrUpdates();

		if (leadOffsetByLayoutView != null)
			leadOffsetByLayoutView.suspendXfrUpdates();

		if (singleLeadView != null)
			singleLeadView.suspendXfrUpdates();
		}
	
	public void resumeXfrUpdates()
		{		
		suspendXfrUpdates = false;
		
		if (leadOffsetByGraphView != null)
			leadOffsetByGraphView.resumeXfrUpdates();

		if (leadOffsetByLayoutView != null)
			leadOffsetByLayoutView.resumeXfrUpdates();

		if (singleLeadView != null)
			singleLeadView.resumeXfrUpdates();
		}

	private void displayHelp(int mTextResourceId)
		{
		if (mTextResourceId <= 0) mTextResourceId = R.string.no_help_available;

		LayoutInflater inflater = LayoutInflater.from(this);
		final View inflatedHelpView = inflater.inflate(R.layout.activity_main_help_layout, null);

		final TextView textView = (TextView) inflatedHelpView.findViewById (R.id.activity_main_topic_text);
		textView.setMovementMethod (LinkMovementMethod.getInstance());

		final float densityScale = getResources().getDisplayMetrics().density;
		textView.setTextSize((densityScale>1.1f)?12.f:18.f);
		textView.setText (Html.fromHtml(getString(mTextResourceId), new Html.ImageGetter()
    		{
			@Override
			public Drawable getDrawable(String source)
        		{
				int id;

				if (source.equals("bar_chart64/"))
					id = R.drawable.bar_chart64;
				else if (source.equals("cap5/"))
					id = R.drawable.cap5;
				else if (source.equals("graph3/"))
					id = R.drawable.graph3;
				else
					return null;
				Bitmap fgBitmap = BitmapFactory.decodeResource(getResources(), id);
        	
				Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
				Bitmap bgBitmap = Bitmap.createBitmap(fgBitmap.getWidth(), fgBitmap.getHeight(), conf); // this creates a MUTABLE bitmap
				Canvas bgCanvas = new Canvas(bgBitmap);
				bgCanvas.drawColor(Color.BLACK);
        	        	
				Bitmap mergedBitmap = Bitmap.createBitmap(fgBitmap.getWidth(), fgBitmap.getHeight(), conf); // this creates a MUTABLE bitmap
				Canvas mergedCanvas = new Canvas(mergedBitmap);
				mergedCanvas.drawBitmap(bgBitmap, new Matrix(), null);
				mergedCanvas.drawBitmap(fgBitmap, new Matrix(), null);
				Drawable mergedDrawable = new BitmapDrawable(getResources(), mergedBitmap);
				mergedDrawable.setBounds(0, 0, 32, 32);
        	
				bgBitmap.recycle();
				fgBitmap.recycle();
        	
				return mergedDrawable;
        		}
    		}, null));    		

		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		int height = size.y;
		helpPopupWindow = new PopupWindow(inflatedHelpView, (width*2)/3, (height*2)/3, true);
		helpPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener()
			{
			@Override
			public void onDismiss()
				{
				helpPopupWindow = null;
				}
			});
	
		inflatedHelpView.setOnTouchListener(new View.OnTouchListener()
			{
			@Override
			public boolean onTouch(View v, MotionEvent event)
				{
				if (helpPopupWindow != null)
					{
					helpPopupWindow.dismiss();
					helpPopupWindow = null;
					}
				return true;
				}
			});

		helpPopupWindow.setOutsideTouchable(true);

		LinearLayout mainLayout = new LinearLayout(this);
		helpPopupWindow.showAtLocation(mainLayout, Gravity.CENTER, 10, 10);
		}
	}