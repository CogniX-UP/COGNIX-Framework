package com.biosemi.bschannelviewer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.Toast;

public class RemoteAcquisitionFragment extends Fragment
	{
    // Debugging
    private static final String TAG = "RemoteAcquisitionFragment";
    private static final boolean D = false;
    
	// the client socket
	private Socket socket;
	
	// the input stream
	private BufferedInputStream	bufferedInputStream;
	private BufferedOutputStream	bufferedOutputStream;
	private DataInputStream	dataInputStream;
	
	// the hostname or ip address of the server
	String host;
	
	// the server port
	int port;
	
	// if the client is connected
	private volatile boolean connected = false;

	// the input reader
	private RemoteAcquisitionInputReader inputReader;
	
	private int	sampleBufferSizeInts;
	private int[]	sampleBuffer;

	private byte[]	recvSampleBuffer;

	// listeners waiting for samples
	private Set<IAcquisitionSamplesWaiter> acquisitionSamplesListeners = new HashSet<IAcquisitionSamplesWaiter>();
	private boolean	tcpReadingSuspended;
    private AcquisitionControlActivity	acquisitionControlActivity;
    private Thread	inputReaderThread;

    private Integer	sampleBufferSeam=-2;
    private int	sampleBufferCycleNum=0;
    
	private int	staticStatusBitsMask=0xae000000;
	private int	staticStatusBits;					// mk1/2 bit and mode bits to be matched
	private int numChannelsXfr;
	private int remoteNumChannels = 0;
	private int remoteSampleRate = 0;
	private int[]	channelXfrVector;
	private int[]	transferChannelRequestRanges;
	private volatile int	numTransferChannelRequestRanges=0;
	private volatile boolean	changeTransferChannels;
	private int rateBufferCount;
	private final int	numBuffersForRate=10;
	private long msecAfterPrevBuffer;
	private volatile double	bytesPerMsec;
	private volatile int	numReSyncs=0;
	private int	numChannelsToRequest;

public RemoteAcquisitionFragment()
	{
	}

@Override
public void onCreate(Bundle bundle)
	{
    /**
     * note: called when fragment is added but not when attached
     * 
     */
	super.onCreate(bundle);

	if (D) Log.d(TAG, "create RemoteAcquisitionFragment (taskId "+getActivity().getTaskId()+", fragId "+getId()+")");
	
	setRetainInstance(true);

	String ipAddrString;
	String portString;
	
	Bundle argBundle = getArguments();
	ipAddrString = argBundle.getString("ipAddr");
	portString = argBundle.getString("port");
	
	if (D) Log.d(TAG, "getArguments bundle: ipAddrString "+ipAddrString);

	numChannelsToRequest = argBundle.getInt("num_channels_to_request", 0);

	acquisitionControlActivity = (AcquisitionControlActivity)getActivity();
	
	host = ipAddrString;
	
	port = 0;
	if ((portString != null) && (portString.length() > 0))
		port = Integer.valueOf(portString);
	if (port <= 0)
		port = 3113;
    	
	inputReader = new RemoteAcquisitionInputReader();
		
	sampleBuffer = new int[2000000];
	sampleBufferSizeInts = sampleBuffer.length;
	recvSampleBuffer = new byte[512000*8*2];
	inputReaderThread = new Thread(inputReader);
	inputReaderThread.setDaemon(true);

	Toast toast = Toast.makeText(acquisitionControlActivity.getApplicationContext(),
		"Trying connection to "+host+","+port, Toast.LENGTH_LONG);
	toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
	toast.show();

	inputReaderThread.start();
	}

public void disconnect()
	{
	if(!connected)
		{
		return;
		}

	connected = false;

	try
		{
		bufferedInputStream.close();
		bufferedOutputStream.close();
		socket.close();
		}
	catch (IOException e)
		{
		System.err.println(String.format("Disconnect error"));
		}
	}

public boolean isConnected()
	{
	return this.connected;
	}

// keep track of which activity instance (if any) this fragment is connected to
// (changes with configuration changes)

@Override
public void onDetach()
	{
	super.onDetach();
	acquisitionControlActivity = null;
	}

@Override
public void onAttach(Activity activity)
	{
	super.onAttach(activity);
	acquisitionControlActivity = (AcquisitionControlActivity)activity;
	}


public void addAcquisitionSamplesListener(IAcquisitionSamplesWaiter waiter)
	{
	synchronized (acquisitionSamplesListeners)
		{
		if (acquisitionSamplesListeners.isEmpty())
			{
			acquisitionSamplesListeners.add(waiter);
			}
		else if (!acquisitionSamplesListeners.contains(waiter))
			acquisitionSamplesListeners.add(waiter);
		}
	}

public void removeAcquisitionSamplesListener(IAcquisitionSamplesWaiter waiter)
	{
	synchronized (acquisitionSamplesListeners)
		{
		acquisitionSamplesListeners.remove(waiter);
		}
	}

protected void notifyAcquisitionSamplesListeners(int cycleNum, int seamIndex)
	{
	synchronized (acquisitionSamplesListeners)
		{
//System.out.println("notify "+newActiViewPacketListeners.size()+" packet listeners for seamIndex "+seamIndex);
		Iterator<IAcquisitionSamplesWaiter> iterator = acquisitionSamplesListeners.iterator();
		while (iterator.hasNext())
			{
			IAcquisitionSamplesWaiter waiter = ((IAcquisitionSamplesWaiter)iterator.next());
//		if (((View)waiter).isShown())
			waiter.newAcquisitionSamples(cycleNum, seamIndex);
			}
		}
	}

public int getRemoteNumChannels()
	{
	return remoteNumChannels;
	}

public int getRemoteNumChannelsXfr()
	{
	return numChannelsXfr;
	}

public int getRemoteSampleRate()
	{
	return remoteSampleRate;
	}

public int[] getSampleBuffer()
	{
	return sampleBuffer;
	}

public int getSampleBufferSizeInts()
	{
	return sampleBufferSizeInts;
	}

public boolean isChannelValid(int chan)
	{
	boolean result = false;
	
	if (channelXfrVector != null)
		for (int i=0; i<channelXfrVector.length; i++)
			if (chan == channelXfrVector[i])
				{
				result = true;
				break;
				}
	
	return result;
	}

private class RemoteAcquisitionInputReader implements Runnable
	{
	/* callers can track filling of the sample buffer by:
	 * either registering an IAcquisitionSamplesWaiter callback to be 
	 *        activated whenever a new buffer of samples moves the
	 *        "ring buffer" pointer  
	 * or invoking the "getSampleBufferSeam" method from time-to-time.
	 */
	private int	seamIndex = 0;
	private int	recvSampleBufferSeam;
	private int recvBufferSizeInBytes;
	
	public RemoteAcquisitionInputReader()
		{
		}
	
	public void run()
		{
		try
			{
			socket = new Socket();
			
			socket.connect(new InetSocketAddress(host, port), 5000);		// 5 second timeout
						
			socket.setReceiveBufferSize(50000);
			recvBufferSizeInBytes = socket.getReceiveBufferSize();
			if (recvBufferSizeInBytes > 50000)
				recvBufferSizeInBytes = 50000;

			bufferedInputStream = new BufferedInputStream(socket.getInputStream());
			dataInputStream = new DataInputStream(bufferedInputStream);
			bufferedOutputStream = new BufferedOutputStream(socket.getOutputStream());
			connected = true;
			}
		catch (IllegalArgumentException e)
			{
			System.err.println(String.format("Unknown Host: %s", host));
			connected = false;
			}
		catch (IOException e)
			{
			System.err.println(String.format("Could not connect to %s:%s", host, port));
			connected = false;
			}

		if (connected)
			{
			remoteNumChannels = 0;
			remoteSampleRate = 0;

			// determine number of channels available (i.e. being sampled by the remote server)
			// and the approximate sample rate per channel
			
			byte[] negBuffer = new byte[128];
			int negRead = 0;
			try {
				negRead = dataInputStream.read(negBuffer, 0, 128);
				}
			catch (IOException e1)
				{
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
			
			if (negRead == 128)
				{
				remoteNumChannels = ((int)(negBuffer[0])&0xff)|(((int)(negBuffer[1])&0xff)<<8)|(((int)(negBuffer[2])&0xff)<<16)|
						((int)(negBuffer[3])<<24);
				remoteSampleRate = ((int)(negBuffer[4])&0xff)|(((int)(negBuffer[5])&0xff)<<8)|(((int)(negBuffer[6])&0xff)<<16)|
						((int)(negBuffer[7])<<24);
				}

			System.out.println("remoteNumChannels = "+remoteNumChannels+", remoteSampleRate = "+remoteSampleRate);

			if ((remoteNumChannels <= 0) || (remoteSampleRate <= 0))
				{
				System.out.println("closing input socket");
				disconnect();
				return;
				}
				
			// tell server which channels to transfer
				
			for (int i=0; i<128; i++)
				negBuffer[i] = 0;
				
			if (numTransferChannelRequestRanges == 0)
				{
				// request all available channels
				if (numChannelsToRequest == 0)
					numChannelsXfr = remoteNumChannels;
				else
					numChannelsXfr = numChannelsToRequest + 2;		// 2 more for sync, status

				negBuffer[0] = 1;
				negBuffer[1] = 0;
				negBuffer[2] = 0;
				negBuffer[3] = 0;
				negBuffer[4] = (byte)(numChannelsXfr & 0xff);
				negBuffer[5] = (byte)((numChannelsXfr/256) & 0xff);
				negBuffer[6] = 0;
				negBuffer[7] = 0;
				negBuffer[8] = 0;
				negBuffer[9] = 0;
				negBuffer[10] = 0;
				negBuffer[11] = 0;
				}
			
			else
				{
				// request selected channels
				numChannelsXfr = 0;
				for (int i=0, j=0, k=0; i<numTransferChannelRequestRanges; i++)
					{
					int firstChan = transferChannelRequestRanges[j++];
					negBuffer[k++] = (byte)(firstChan & 0xff);
					negBuffer[k++] = (byte)((firstChan/256) & 0xff);
					k += 2;

					int lastChan = transferChannelRequestRanges[j++];
					negBuffer[k++] = (byte)(lastChan & 0xff);
					negBuffer[k++] = (byte)((lastChan/256) & 0xff);
					k += 2;
						
					numChannelsXfr += lastChan - firstChan + 1;
					}
				}
								
			try
				{
				bufferedOutputStream.write(negBuffer);
				bufferedOutputStream.flush();
				}
			catch (IOException e1)
				{
				// TODO Auto-generated catch block
				e1.printStackTrace();
				}
			
			// setup transferred channels placement vector 

			if (numTransferChannelRequestRanges == 0)
				{
				// all channels being transferred so setup one-to-one placement vector
				channelXfrVector = new int[numChannelsXfr];
				for (int i=0; i<numChannelsXfr; i++)
					channelXfrVector[i] = i;
				}
			else
				{
				// selected channels being transferred so setup a scatter placement vector
				channelXfrVector = new int[numChannelsXfr];
				for (int i=0, j=0, k=0; i<numTransferChannelRequestRanges; i++)
					{
					int firstChan = transferChannelRequestRanges[j++];
					int lastChan = transferChannelRequestRanges[j++];
					for (int ch=firstChan; ch<=lastChan; ch++)
						channelXfrVector[k++] = ch-1;
					}
				}
			
			recvSampleBufferSeam = 0;		
			int numChannels = remoteNumChannels;
			int numSamples = 0;
			int numNewBytesXfr = 0;
			boolean firstRead = true;
			boolean reSyncNeeded = false;
			int prevSam = 0;
			changeTransferChannels = false;
	
			// initialize buffer timing
			rateBufferCount = numBuffersForRate;
			msecAfterPrevBuffer = System.nanoTime()/1000000;
			
			numReSyncs = 0;			// count re-syncs

			try
				{
				tcpReadingSuspended = false;
				sampleBufferSeam = -3;
				sampleBufferCycleNum = 0;
				while(connected)
					{
					// each sample is transferred as 3 bytes;
					// 4 samples occupy 3 32 bit words
					// (#channels * 3) usually won't fully occupy a whole number of 32 bit words
					// (i.e. the last 32 bit word may use only 1, 2 or 3 bytes)
					//
					// if we always request multiple of 4 times the number of channels being
					// transferred, all bytes in that last 32 bit word will be used (i.e,
					// no sample will span 2 input buffers)
					//
					int toRead = (recvBufferSizeInBytes/(numChannelsXfr*3*4))*(numChannelsXfr*3*4);
				
					// read until the recv buffer is full
					int leftToRead = toRead;
					int thisRead = 0;
					while(leftToRead > 0) 
						{
						// raw buffer input
						thisRead = dataInputStream.read(recvSampleBuffer, recvSampleBufferSeam+toRead-leftToRead, leftToRead);

						if (thisRead < 0)
							{
							// remote system closes the stream when it detects overrun (i.e. client is not
							// able to keep up; try reconnecting without re-negotiating the xfr channels 
							System.out.println("input socket closed - try reconnect");
							numReSyncs++;			// count re-synsc
							reConnectInputStream();
							if (connected == false)
								{
								System.out.println("reconnection failed");
								thisRead = -1;
								break;
								}

							// try read again
							connected = false;
							leftToRead = toRead;
							thisRead = dataInputStream.read(recvSampleBuffer, recvSampleBufferSeam+toRead-leftToRead, leftToRead);
							if (thisRead < 0)
								{
								System.out.println("reconnection failed");
								break;
								}
							System.out.println("reconnected");
							connected = true;
							}

						leftToRead -= thisRead;
						}
					
				if (thisRead < 0)
					{
System.out.println("bufferedInputStream.read returns "+thisRead+", leftToRead = "+leftToRead+", toRead = "+toRead);
//					break;
					}
				
				int bytesRead = toRead - leftToRead;
				if (bytesRead <= 0)
					{
System.out.println("bytesRead = "+bytesRead);
					break;
					}

				numNewBytesXfr = toRead;
				
				// always uncompress and inflate a multiple of 4 sample sets
				int numBytesPer4Sets = numChannelsXfr*4*3;
				int numNewSetBytesXfr = (numNewBytesXfr/numBytesPer4Sets)*numBytesPer4Sets;
				numNewBytesXfr -= numNewSetBytesXfr;

				int numNewSets = numNewSetBytesXfr/(numChannelsXfr*3);

				int[] s = new int[4];			// 4 output samples
				s[0] = s[1] = s[2] = s[3] = 0;	// to suppress compiler's uninitialized warning

				int ps1,ps2,ps3;	// 3 input packed samples
				ps1 = ps2 = ps3 = 0;		// to suppress compiler's uninitialized warning

				int srcx = 0;

				int destx = seamIndex;
				if (destx == sampleBufferSizeInts)
					destx = 0;
								
				// unpack 4th sample from the spare low order bytes in the 1st 3 samples
				int sX = 4;
				for (int numSets=0; numSets<numNewSets; numSets++)
					{
					int ch = 0;
					for (ch=0; ch<numChannelsXfr; ch++)
						{
						int sam = 0;
						int chXfr = channelXfrVector[ch];
						if (sX > 3)
							{// time to reload 3 words to create 4 samples (s[0]-s[3])
							ps1 = ((int)(recvSampleBuffer[srcx++])&0xff)|(((int)(recvSampleBuffer[srcx++])&0xff)<<8)|(((int)(recvSampleBuffer[srcx++])&0xff)<<16)|
								((int)(recvSampleBuffer[srcx++])<<24);
							ps2 = ((int)(recvSampleBuffer[srcx++])&0xff)|(((int)(recvSampleBuffer[srcx++])&0xff)<<8)|(((int)(recvSampleBuffer[srcx++])&0xff)<<16)|
								((int)(recvSampleBuffer[srcx++])<<24);
							ps3 = ((int)(recvSampleBuffer[srcx++])&0xff)|(((int)(recvSampleBuffer[srcx++])&0xff)<<8)|(((int)(recvSampleBuffer[srcx++])&0xff)<<16)|
								((int)(recvSampleBuffer[srcx++])<<24);

							s[0] = (int)(ps1 & 0xffffff00);
							s[1] = (int)(ps2 & 0xffffff00);
							s[2] = (int)(ps3 & 0xffffff00);
							s[3] = (int)(((ps1&0xff)<<24) | ((ps2&0xff)<<16) | ((ps3&0xff)<<8));

							sX = 0;
							}

						sam = s[sX++];

						numSamples++;
								
						if (reSyncNeeded == false)
							{
							if (destx+chXfr < sampleBufferSizeInts)
								sampleBuffer[destx+chXfr] = sam;
							else
								sampleBuffer[destx+chXfr-sampleBufferSizeInts] = sam;
						
							if ((firstRead == true) && (destx == 0) && (chXfr == 1))
								{
								staticStatusBits = sam & staticStatusBitsMask;
								firstRead = false;
								}
							
							if (ch == 1)
								{
								// check for correct presence of sync and status words
								if ((prevSam != 0xffffff00) || ((sam&staticStatusBitsMask) != staticStatusBits))
									{
System.out.println("resync needed - ch 0/1 sync and/or status missing, numSamples = "+numSamples);
									// re-sync needed
									reSyncNeeded = true;
									break;
									}
								}

							prevSam = sam;
							}

						} // ch < numChannels
					
					if (reSyncNeeded == false)
						{
						destx += numChannels;
						if (destx >= sampleBufferSizeInts)
							destx -= sampleBufferSizeInts;
						}

					else
						{
						numReSyncs++;		// count re-syncs
						
						System.out.println("reSyncNeeded - try reconnecting");
						break;
						}
					} // numSets < numNewSets

				seamIndex = destx;
				
				if (connected == false)
					break;

				if ((changeTransferChannels == false) && (!tcpReadingSuspended))
					{
					synchronized (sampleBufferSeam)
						{
						// check if seam wrapped
						if (seamIndex <= sampleBufferSeam.intValue())
							// step cycle#
							sampleBufferCycleNum++;
						sampleBufferSeam = (Integer)seamIndex;
						}
					
					if (changeTransferChannels == false)
						notifyAcquisitionSamplesListeners(sampleBufferCycleNum, sampleBufferSeam.intValue());
					}

				// after every 'numBuffersForRate' recv buffers, calculate recv rate (bytesPerMsec)
				// note: this is the uncompressed data rate which is higher than the raw rate 
				
				if (--rateBufferCount <= 0)
					{
					// reset rate counter
					rateBufferCount = numBuffersForRate;

					// determine time taken to recv these rate buffers

					int	strideInBytes = toRead;
					double  msecOnRateBuffers=1.0;
					long msecNow = System.nanoTime()/1000000;
					msecOnRateBuffers = (double)(msecNow - msecAfterPrevBuffer);
					msecAfterPrevBuffer = msecNow;
					bytesPerMsec = (double)(strideInBytes*numBuffersForRate)/msecOnRateBuffers;
					}

				if ((changeTransferChannels == true) || (reSyncNeeded == true))
					{
					// when the client closes the stream, the xfr channels must be re-negotiated 

					try
						{
						dataInputStream.close();
						bufferedInputStream.close();
						bufferedOutputStream.close();
						socket.close();
						connected = false;
						
						try {
							Thread.sleep(1000);
							}
						catch (InterruptedException e)
							{
							// TODO Auto-generated catch block
							e.printStackTrace();
							}
						
						socket = new Socket();
						socket.connect(new InetSocketAddress(host, port), 5000*4);
						bufferedInputStream = new BufferedInputStream(socket.getInputStream());
						dataInputStream = new DataInputStream(bufferedInputStream);
						bufferedOutputStream = new BufferedOutputStream(socket.getOutputStream());
						connected = true;
				
						// re-initialize buffer timing
						rateBufferCount = numBuffersForRate;
						msecAfterPrevBuffer = System.nanoTime()/1000000;
						}
					catch (IllegalArgumentException e)
						{
						System.err.println(String.format("Unknown Host: %s", host));
						connected = false;
						}
					catch (IOException e)
						{
						System.err.println(String.format("Could not connect to %s:%s", host, port));
						connected = false;
						}
				
				if (connected == false)
					break;		// couldn't re-connect

				// mark connected false until there is a successful read
				connected = false;
				
				// re-select channels to be transferred
				
				for (int i=0; i<128; i++)
					negBuffer[i] = 0;
				
					try {
						negRead = dataInputStream.read(negBuffer, 0, 128);
						}
					catch (IOException e1)
						{
						// TODO Auto-generated catch block
						e1.printStackTrace();
						connected = false;
						break;
						}
					
					if (negRead == 128)
						{
						connected = true;

						remoteNumChannels = ((int)(negBuffer[0])&0xff)|(((int)(negBuffer[1])&0xff)<<8)|(((int)(negBuffer[2])&0xff)<<16)|
								((int)(negBuffer[3])<<24);
						remoteSampleRate = ((int)(negBuffer[4])&0xff)|(((int)(negBuffer[5])&0xff)<<8)|(((int)(negBuffer[6])&0xff)<<16)|
								((int)(negBuffer[7])<<24);
						
						// tell server which channels to transfer
							
						for (int i=0; i<128; i++)
							negBuffer[i] = 0;
							
						if (numTransferChannelRequestRanges == 0)
							{
							// request all available channels
							if (numChannelsToRequest == 0)
								numChannelsXfr = remoteNumChannels;
							else
								numChannelsXfr = numChannelsToRequest + 2;		// 2 more for sync, status

							negBuffer[0] = 1;
							negBuffer[1] = 0;
							negBuffer[2] = 0;
							negBuffer[3] = 0;
							negBuffer[4] = (byte)(numChannelsXfr & 0xff);
							negBuffer[5] = (byte)((numChannelsXfr/256) & 0xff);
							negBuffer[6] = 0;
							negBuffer[7] = 0;
							negBuffer[8] = 0;
							negBuffer[9] = 0;
							negBuffer[10] = 0;
							negBuffer[11] = 0;
							}
						
						else
							{
							// request selected channels
							numChannelsXfr = 0;
							for (int i=0, j=0, k=0; i<numTransferChannelRequestRanges; i++)
								{
								int firstChan = transferChannelRequestRanges[j++];
								negBuffer[k++] = (byte)(firstChan & 0xff);
								negBuffer[k++] = (byte)((firstChan/256) & 0xff);
								k += 2;

								int lastChan = transferChannelRequestRanges[j++];
								negBuffer[k++] = (byte)(lastChan & 0xff);
								negBuffer[k++] = (byte)((lastChan/256) & 0xff);
								k += 2;
									
								numChannelsXfr += lastChan - firstChan + 1;
								}
							}
						
						try
							{
							bufferedOutputStream.write(negBuffer);
							bufferedOutputStream.flush();
							}
						catch (IOException e1)
							{
							// TODO Auto-generated catch block
							e1.printStackTrace();
							}

						}// negread == 128
					
					channelXfrVector = new int[numChannelsXfr];
					for (int i=0, j=0, k=0; i<numTransferChannelRequestRanges; i++)
						{
						int firstChan = transferChannelRequestRanges[j++];
						int lastChan = transferChannelRequestRanges[j++];
						for (int ch=firstChan; ch<=lastChan; ch++)
							channelXfrVector[k++] = ch-1;
						}
					
					reSyncNeeded = false;

					changeTransferChannels = false;
					}// changeTransferChannels == true
				}// connected
				
			}// try
			
		catch(IOException e)
			{
			}
		
		connected = false;
		System.err.println("Remote server disconnected.");
		}// end of if (connected)

		System.out.println("end of connected loop (RemoteAcquisitionFragment");
	}// end of run method
	}// end of private RemoteAcquisitionInputReader class

	private void reConnectInputStream()
		{
		try
			{
			dataInputStream.close();
			bufferedInputStream.close();
			bufferedOutputStream.close();
			socket.close();
			connected = false;

			socket = new Socket();
			socket.connect(new InetSocketAddress(host, port), 5000*4);
			bufferedInputStream = new BufferedInputStream(socket.getInputStream());
			dataInputStream = new DataInputStream(bufferedInputStream);
			bufferedOutputStream = new BufferedOutputStream(socket.getOutputStream());
			connected = true;
			}
		catch (IllegalArgumentException e)
			{
			System.err.println(String.format("Unknown Host: %s", host));
			connected = false;
			}
		catch (IOException e)
			{
			System.err.println(String.format("Could not connect to %s:%s", host, port));
			connected = false;
			}
		}

	public long getSampleBufferSeam()
	// returns:
	// either cycleNum in high order 32 bits, seam in low order 32 bits
	// or a negative number to indicate special conditions
		{
		int seam;
		int cycleNum;
		
		synchronized (sampleBufferSeam)
			{
			cycleNum = sampleBufferCycleNum;
			seam = sampleBufferSeam.intValue();
			}
			
		if ((seam > 0) && (connected == false) || (changeTransferChannels == true))
			seam = -1;
		
		long position = (long)seam;
		// if not negative, put cycleNum in high order 32 bits
		if (seam >= 0)
			position |= ((long)cycleNum)<<32;
		
		return position;
		}
	
	public String getHost()
		{
		return host;
		}
	
	public int getPort()
		{
		return port;
		}

	public int[] getChannelXfrVector()
		{
		return channelXfrVector;
		}
	
	public boolean setTransferChannelRequestRanges(int numRanges, int[] channelRanges)
		{
		boolean	ret;

		ret = false;
		int numRangeInts = numRanges*2;
		int rangeInt = 0;
		for ( ; rangeInt<numRangeInts; )
			{
			int first = channelRanges[rangeInt++];
			if (first < 1)
				break;
			int last = channelRanges[rangeInt++];
			if (last < first)
				break;
			if (rangeInt > 2)
				if (first <= channelRanges[rangeInt-3])
					break;          // first overlays previous range 
			}

		if (rangeInt == numRangeInts)
			{
			if (transferChannelRequestRanges != null)
				{
				transferChannelRequestRanges = null;
				}

			if (numRangeInts > 0)
				{
				transferChannelRequestRanges = new int[numRangeInts];

				for (int i=0; i<numRangeInts; i++)
					transferChannelRequestRanges[i] = channelRanges[i];
				}

			numTransferChannelRequestRanges = numRanges;

			ret = true;

			changeTransferChannels = true;
			}
		else
			ret = false;

		return ret;
		}

	public float getBytesPerMsec()
		{
		return (float)bytesPerMsec;
		}
	
	public int getNumReSyncs()
		{
		return numReSyncs;
		}
	}// end of RemoteAcquisitionFragment class
