package com.biosemi.bschannelviewer;

import java.util.Set;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;

public class LeadOffsetByGraphView extends View
	{
	
	// variables that must be saved/restored when orientation changes 
	
	private int	ampMax;

	// other variables

	private Bitmap	bgImage;
	private RemoteAcquisitionFragment	remoteAcquisitionFragment;
	private int	numLGChannels;
	private int	numEXChannels;
	private int	remoteNumChannels;
	private int	remoteNumChannelsXfr;
	private int[]	sampleBuffer;
	private int	sampleBufferSizeInts;
	private AcquisitionControlActivity	acquisitionControlActivity;
	private int	numLeadGroups;

	private float exPanelWidth_f;
	private float lgPanelWidth_f;
	private float ticksWidth_f;

	private float exPanelLeftMargin_f;

	private float lgPanelRightMargin_f;
	private float lgPanelLeftMargin_f;
	
	private float lgPanelHeight_f;
	
	private float lgUpperPanelTopMargin_f;
	private float lgLowerPanelBottomMargin_f;
	private float lgLowerPanelTopMargin_f;  

	private float exPanelHeight_f;
	private float exUpperPanelTopMargin_f;
	private float exLowerPanelTopMargin_f;
	private float exLowerPanelBottomMargin_f;

	private long	lastPosition;
	private boolean[]	channelIsValid;
	private int	showAbsChan;
	private GestureDetector gestureDetector;
	private RectF[]	lgRectangles;
	private RectF[]	exRectangles;
	private boolean	suspendXfrUpdates;
	private boolean verticalOrientation;
	
	public LeadOffsetByGraphView(Context context, RemoteAcquisitionFragment ravf, AcquisitionControlActivity naa, Bundle inState)
		{
		super(context);
		acquisitionControlActivity = naa;
		remoteAcquisitionFragment = ravf;
		
		// initialize all saved state variables
			
		ampMax = 262;

		// restore any saved state
		if (inState != null)
			onRestoreInstanceState(inState);
		
		sampleBufferSizeInts = -1;
		numEXChannels = 8;
		remoteNumChannels = 0;
		remoteNumChannelsXfr = 0;
		showAbsChan = acquisitionControlActivity.getChannelToPlot();
		suspendXfrUpdates = false;

		verticalOrientation = false;
		if (acquisitionControlActivity.getResources().getConfiguration().orientation ==  Configuration.ORIENTATION_PORTRAIT)
			verticalOrientation = true;
		
		updateDisplay();

		gestureDetector = new GestureDetector(context, new SimpleOnGestureListener()
			{
			// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true

			@Override
			public boolean onDown(MotionEvent evt)
				{
				// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true
				return true;
				}
		
			@Override
			public boolean onDoubleTap(MotionEvent evt)
				{
				// cycle through possible amplitude scales
				boolean result = false;

				int newAmpMax = ampMax;
				
				if (ampMax == 262)
					newAmpMax = 100;
				else if (ampMax == 100)
					newAmpMax = 50;
				else if (ampMax == 50)
					newAmpMax = 20;
				else if (ampMax == 20)
					newAmpMax = 262;

				if (newAmpMax != ampMax)
					{
					ampMax = newAmpMax;
					invalidate();
					
					result = true;
					}
			
				return result;
				}// onDoubleTap()

			@Override
			public boolean onSingleTapConfirmed(MotionEvent evt)
				{
				// select a channel
				boolean result = false;

				// monitor only when doing single touch
				if (evt.getPointerCount() > 1)
					return false;

				int pointerIndex = evt.getActionIndex();
				int x = (int)evt.getX(pointerIndex);
				int y = (int)evt.getY(pointerIndex);
				
				float xf = (float)x;
				float yf = (float)y;

				for (int i=0; i<numLeadGroups; i++)
					if ((lgRectangles[i] != null) && (lgRectangles[i].contains(xf, yf)))
						{
						// interpolate a group lead number
						int leadOffset = (int)(((xf - lgRectangles[i].left)/lgRectangles[i].width())*32.0f);
						if (leadOffset < 0)
							leadOffset = 0;
						else if (leadOffset > 31)
							leadOffset = 31;
						acquisitionControlActivity.setChannelToPlot(2+i*32+leadOffset);
						result = true;
						break;
						}
				
				if (result == false)
					if (exRectangles != null)
						{
						for (int i=0; i<2; i++)
							{
							if ((exRectangles[i] != null) && (exRectangles[i].contains(xf, yf)))
								{
								// interpolate an ex lead number
								int leadOffset = (int)(((xf - exRectangles[i].left)/exRectangles[i].width())*4.0f);
								if (leadOffset < 0)
									leadOffset = 0;
								else if (leadOffset > 3)
									leadOffset = 3;
								acquisitionControlActivity.setChannelToPlot(2+numLeadGroups*32+i*4+leadOffset);
								result = true;
								break;
								}
							}
						}
			
				return result;
				}// onSingleTapConfirmed()
			
			});// SimpleOnGestureListener()
		
		setOnTouchListener(new OnTouchListener()
			{
			@Override
			public boolean onTouch(View v, MotionEvent evt)
				{
				return gestureDetector.onTouchEvent(evt);
				}
			});
		
		}// LeadOffsetByGraphView() class constructor
	
	private void updateDisplay()
		{
		/*
		 * driven by either postDelayed run requests scheduled below or onVisibilitycChanged calls;
		 * tracks "ring buffer" position by getSampleBufferSeam calls
		*/
		long position = remoteAcquisitionFragment.getSampleBufferSeam();
		if (position != lastPosition)
			{
			if (position >= 0)
				{
				lastPosition = position;
				
				// samples are now being read so get remote values if not already known

				if (remoteNumChannels == 0)
					{
					remoteNumChannels = remoteAcquisitionFragment.getRemoteNumChannels();
					if (remoteNumChannels > 0)
						{
						numLeadGroups = (remoteNumChannels-2)/32;
						lgRectangles = new RectF[numLeadGroups];
						exRectangles = new RectF[2];
						}
					}
					
				if (remoteNumChannelsXfr == 0)
					{
					remoteNumChannelsXfr = remoteAcquisitionFragment.getRemoteNumChannelsXfr();
				
					// setup valid channel array
					int[] channelXfrVector = remoteAcquisitionFragment.getChannelXfrVector();
					if (channelXfrVector != null)
						{
						channelIsValid = new boolean[remoteNumChannels];
					
						for (int i=0; i<remoteNumChannels; i++)
							channelIsValid[i] = false;
					
						for (int i=0; i<remoteNumChannelsXfr; i++)
							channelIsValid[channelXfrVector[i]] = true;
						}
					}
			
				if ((isShown() && (suspendXfrUpdates == false)))
					invalidate();
				}// position >= 0

			// re-schedule in 1 second
			postDelayed(new Runnable()
				{
				@Override
				public void run()
					{
					updateDisplay();
					}
				}, 1000);		// run again in 1 second
			
			}// position != lastPosition
		}// updateDiaplay()

	@Override
	protected void onVisibilityChanged(View v, int visibility)
		{
		if (visibility != GONE)
			updateDisplay();
		}

	@Override
	protected void onDraw(Canvas canvas)
		{
		if (remoteNumChannels == 0)
			return;

		// get view dimensions
		int height = getHeight();
		int width = getWidth();
		 if ((height == 0) || (width == 0))
			 return;
		 
		float width_f = (float)width;
		float height_f = (float)height;

		numLeadGroups = (remoteNumChannels-2)/32;
		numLGChannels = numLeadGroups*32;
		int numDrawChannels = numLGChannels;
		int numEXDrawChannels = 8;
				
		int firstExDrawChannel = 2 + numLGChannels;

		exPanelWidth_f = width_f * 0.06f;
		lgPanelWidth_f = width_f * 0.86f;
		ticksWidth_f = width_f * 0.06f;

		float leftMargin_f = (width_f - exPanelWidth_f - ticksWidth_f - lgPanelWidth_f)/2.f;
		exPanelLeftMargin_f = leftMargin_f;

		lgPanelRightMargin_f = exPanelLeftMargin_f;
		lgPanelLeftMargin_f = width_f - lgPanelRightMargin_f - lgPanelWidth_f;
				
		lgPanelHeight_f = height_f * 0.42f;
		
		lgUpperPanelTopMargin_f = height_f * 0.05f;
		lgLowerPanelBottomMargin_f = lgUpperPanelTopMargin_f;
		lgLowerPanelTopMargin_f = height_f - lgLowerPanelBottomMargin_f - lgPanelHeight_f;
		
		exPanelHeight_f = lgPanelHeight_f * 1.f;
		
		exUpperPanelTopMargin_f = lgUpperPanelTopMargin_f;;
		exLowerPanelTopMargin_f = lgLowerPanelTopMargin_f;
		exLowerPanelBottomMargin_f = lgLowerPanelBottomMargin_f;
				
		int wrapChan = (((numLeadGroups+1)/2)*2*32)/2;
		if (wrapChan < 32)
			wrapChan = 32;
		
		float pixelsPerLGChannel_f = lgPanelWidth_f/(float)wrapChan;
		float pixelsPerEXChannel_f = exPanelWidth_f/4.f;

		float pixelsPerLGCount_f = lgPanelHeight_f/2.0f/(float)ampMax;
		float pixelsPerEXCount_f = exPanelHeight_f/2.0f/(float)ampMax;
				
		float ampMax_f = (float)ampMax;
		float pixelsPerCount = lgPanelHeight_f/2.0f/ampMax_f;
		
		int numHorizontalTicks = 7;
		int tickInc = 50;

		if (ampMax == 20)
			{
			numHorizontalTicks = 5;
			tickInc = 5;
			}
		else if (ampMax == 50)
			{
			numHorizontalTicks = 6;
			tickInc = 10;
			}
		else if (ampMax == 100)
			{
			numHorizontalTicks = 6;
			tickInc = 20;
			}
		
		Paint offsetPaint = new Paint();

		if (bgImage == null)
			{
			createBackgroundBitmap(width, height, ampMax, tickInc, numHorizontalTicks, numDrawChannels, numEXChannels, 0,
				pixelsPerLGChannel_f, pixelsPerLGCount_f, pixelsPerEXChannel_f, verticalOrientation);
			}

		canvas.drawBitmap(bgImage, 0.f, 0.f, null);
		
		long position = remoteAcquisitionFragment.getSampleBufferSeam();

		if (position < 0)
			return;		// no samples yet
		
		int seam = (int)(position&0xffffffff);
		
		if (sampleBufferSizeInts == -1)
			{
			sampleBuffer = remoteAcquisitionFragment.getSampleBuffer();
			sampleBufferSizeInts = remoteAcquisitionFragment.getSampleBufferSizeInts();
			}

		int lastTupleIndex = seam - remoteNumChannels;
		if (lastTupleIndex < 0)
			lastTupleIndex += sampleBufferSizeInts;
				
		float lgUpperPanelZeroLine = lgUpperPanelTopMargin_f + lgPanelHeight_f/2.f;
		float lgLowerPanelZeroLine = lgLowerPanelTopMargin_f + lgPanelHeight_f/2.f;

		offsetPaint.setStrokeWidth(0.0f);

		// plot main lead group channels
		
		for (int chan=0; chan<numDrawChannels; chan++)
			{
			if (!channelIsValid[2+chan])
				continue;			// don't plot those without valid samples
			
			float xStart = lgPanelLeftMargin_f + (float)((chan<wrapChan)?chan:(chan-wrapChan)) * pixelsPerLGChannel_f;
			float xEnd = xStart + pixelsPerLGChannel_f;
			if ((chan != wrapChan-1) && (chan != numDrawChannels-1))
				xEnd -= 1.f;
			
			int samp = 0;
			if (!channelIsValid[2+chan])
				samp = 0xffffff00;
			else if (lastTupleIndex+2+chan < sampleBufferSizeInts)
				samp = sampleBuffer[lastTupleIndex+2+chan];
			else
				samp = sampleBuffer[lastTupleIndex+2+chan-sampleBufferSizeInts];
			
			float sample = (float)samp/31.25f/1000.f;		// mvolts
			if (sample > ampMax_f)
				sample = ampMax_f;
			else if (sample < -ampMax_f)
				sample = -ampMax_f;
			float amp = ((chan<wrapChan)?lgUpperPanelZeroLine:lgLowerPanelZeroLine) - sample*pixelsPerCount;

			if (2+chan == showAbsChan)
				offsetPaint.setColor(Color.GREEN);				
			else if (!channelIsValid[2+chan])
				offsetPaint.setColor(Color.BLACK);
			else
				offsetPaint.setColor((ampMax==262)?Color.RED:Color.BLUE);
							
			if (chan < wrapChan)
				{
				if (Math.abs(amp-lgUpperPanelZeroLine) < 1.0f)
					canvas.drawLine(xStart, amp, xEnd, amp, offsetPaint);
				else
					canvas.drawRect(xStart, (amp<lgUpperPanelZeroLine)?amp:lgUpperPanelZeroLine, xEnd, amp<lgUpperPanelZeroLine?lgUpperPanelZeroLine:amp, offsetPaint);
				}
			else
				{
				if (Math.abs(amp-lgLowerPanelZeroLine) < 1.0f)
					canvas.drawLine(xStart, amp, xEnd, amp, offsetPaint);
				else
					canvas.drawRect(xStart, (amp<lgLowerPanelZeroLine)?amp:lgLowerPanelZeroLine, xEnd, amp<lgLowerPanelZeroLine?lgLowerPanelZeroLine:amp, offsetPaint);
				}
			
			}// for all channel groups

		// plot ex channels
		
		float exUpperPanelZeroLine_f = exUpperPanelTopMargin_f + exPanelHeight_f/2.f;
		float exLowerPanelZeroLine_f = exLowerPanelTopMargin_f + exPanelHeight_f/2.f;
		int wrapExChan = numEXDrawChannels/2;
		for (int chan=0; chan<numEXDrawChannels; chan++)
			{
			if (!channelIsValid[firstExDrawChannel+chan])
				continue;			// don't plot those without valid samples

			float xStart = exPanelLeftMargin_f + (float)((chan<wrapExChan)?chan:(chan-wrapExChan)) * pixelsPerEXChannel_f;
			float xEnd = xStart + pixelsPerEXChannel_f;
			if ((chan != wrapExChan-1) && (chan != numEXDrawChannels-1))
				xEnd -= 1.f;
		
			int samp = 0;
			if (!channelIsValid[firstExDrawChannel+chan])
				samp = 0xffffff00;
			else if (lastTupleIndex+firstExDrawChannel+chan < sampleBufferSizeInts)
				samp = sampleBuffer[lastTupleIndex+firstExDrawChannel+chan];
			else
				samp = sampleBuffer[lastTupleIndex+firstExDrawChannel+chan-sampleBufferSizeInts];

			float sample = (float)samp/31.25f/1000.f;		// mvolts
			if (sample > ampMax_f)
				sample = ampMax_f;
			else if (sample < -ampMax_f)
				sample = -ampMax_f;
			float amp = ((chan<wrapExChan)?exUpperPanelZeroLine_f:exLowerPanelZeroLine_f) - sample*pixelsPerEXCount_f;
			
			if (firstExDrawChannel+chan == showAbsChan)
				offsetPaint.setColor(Color.GREEN);				
			else if (!channelIsValid[firstExDrawChannel+chan])
				offsetPaint.setColor(Color.BLACK);
			else
				offsetPaint.setColor((ampMax==262)?Color.RED:Color.BLUE);
			
			if (chan < wrapExChan)
				{
				if (Math.abs(amp-exUpperPanelZeroLine_f) < 1.0f)
					canvas.drawLine(xStart, amp, xEnd, amp, offsetPaint);
				else
					canvas.drawRect(xStart, (amp<exUpperPanelZeroLine_f)?amp:exUpperPanelZeroLine_f, xEnd, amp<exUpperPanelZeroLine_f?exUpperPanelZeroLine_f:amp, offsetPaint);
				}
			else
				{
				if (Math.abs(amp-exLowerPanelZeroLine_f) < 1.0f)
					canvas.drawLine(xStart, amp, xEnd, amp, offsetPaint);
				else
					canvas.drawRect(xStart, (amp<exLowerPanelZeroLine_f)?amp:exLowerPanelZeroLine_f, xEnd, amp<exLowerPanelZeroLine_f?exLowerPanelZeroLine_f:amp, offsetPaint);
				}

			}
		}// onDraw()

	private void createBackgroundBitmap(int width, int height, int maxY, int tickInc, int numHorizontalTicks, int numLGChan, int numEXChan, int firstChan,
		float pixelsPerLGChannel_f, float pixelsPerLGCount_f, float pixelsPerEXChannel_f, boolean verticalOrientation)
		{
		// build a new background (unchanging) image
		
		if (bgImage != null)
			bgImage.recycle();

		bgImage = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		
    	Canvas bgCanvas = new Canvas(bgImage);
    	
//		float width_f = (float)width;
		float height_f = (float)height;

		Paint offsetPaint = new Paint();
		offsetPaint.setColor(Color.BLACK);

		// flood fill the background
		
		int frameColor = Color.rgb(0x95, 0x8d, 0xb6);
		bgCanvas.drawColor(frameColor);

		RectF lgUpperPanelRect = new RectF(lgPanelLeftMargin_f, lgUpperPanelTopMargin_f, lgPanelLeftMargin_f+lgPanelWidth_f, lgUpperPanelTopMargin_f+lgPanelHeight_f); 
		RectF lgLowerPanelRect = new RectF(lgPanelLeftMargin_f, lgLowerPanelTopMargin_f, lgPanelLeftMargin_f+lgPanelWidth_f, lgLowerPanelTopMargin_f+lgPanelHeight_f); 

		RectF exUpperPanelRect = new RectF(exPanelLeftMargin_f, exUpperPanelTopMargin_f, exPanelLeftMargin_f+exPanelWidth_f, exUpperPanelTopMargin_f+exPanelHeight_f); 
		RectF exLowerPanelRect = new RectF(exPanelLeftMargin_f, exLowerPanelTopMargin_f, exPanelLeftMargin_f+exPanelWidth_f, exLowerPanelTopMargin_f+exPanelHeight_f); 
		
		// flood fill the lg panels 
		
		int innerColor = Color.rgb(0xcc, 0xcc, 0xff);
		offsetPaint.setColor(innerColor);
		offsetPaint.setStyle(Paint.Style.FILL);

		bgCanvas.drawRect(lgUpperPanelRect, offsetPaint);
		bgCanvas.drawRect(lgLowerPanelRect, offsetPaint);

		// flood fill the ex panels
		
		offsetPaint.setColor(Color.WHITE);
		
		bgCanvas.drawRect(exUpperPanelRect, offsetPaint);
		bgCanvas.drawRect(exLowerPanelRect, offsetPaint);
		
		int wrapChan = (((numLeadGroups+1)/2)*2*32)/2;
		if (wrapChan < 32)
			wrapChan = 32;
				
		// shade fill each lead group in each panel
		
		float quarterPanelWidth_f = 32.f*pixelsPerLGChannel_f;
		for (int lg=0; lg<numLeadGroups; lg++)
			{
			float lgOffset_f = ((float)(lg%4)) * quarterPanelWidth_f;
			
			if (lg < 4)
				{
				lgRectangles[lg] = new RectF(lgUpperPanelRect.left+lgOffset_f, lgUpperPanelRect.top, lgUpperPanelRect.left+lgOffset_f+quarterPanelWidth_f, lgUpperPanelRect.bottom);
			
				RectF leadGroupRect = lgRectangles[lg];
				offsetPaint.setShader(new LinearGradient(leadGroupRect.left, leadGroupRect.top, leadGroupRect.right, leadGroupRect.bottom,
					innerColor, Color.WHITE, Shader.TileMode.MIRROR));

				bgCanvas.drawRect(leadGroupRect, offsetPaint);
				}
			
			else
				{
				lgRectangles[lg] = new RectF(lgLowerPanelRect.left+lgOffset_f, lgLowerPanelRect.top, lgLowerPanelRect.left+lgOffset_f+quarterPanelWidth_f, lgLowerPanelRect.bottom);
			
				RectF leadGroupRect = lgRectangles[lg];
				offsetPaint.setShader(new LinearGradient(leadGroupRect.left, leadGroupRect.top, leadGroupRect.right, leadGroupRect.bottom,
					innerColor, Color.WHITE, Shader.TileMode.MIRROR));

				bgCanvas.drawRect(leadGroupRect, offsetPaint);
				}
			}// for all channel groups

		offsetPaint.setShader(null);

		float pixelsPerTick_f = pixelsPerLGCount_f * (float)tickInc;
		
		offsetPaint.setColor(Color.BLACK);
		float lgUpperPanelZeroLine_f = lgUpperPanelTopMargin_f + lgPanelHeight_f/2.0f;
		float lgLowerPanelZeroLine_f = lgLowerPanelTopMargin_f + lgPanelHeight_f/2.f;

		float exUpperPanelZeroLine_f = exUpperPanelTopMargin_f + exPanelHeight_f/2.0f;
		float exLowerPanelZeroLine_f = exLowerPanelTopMargin_f + exPanelHeight_f/2.f;
		
		int gridColor = Color.rgb(0xc1, 0xc1, 0xc1);
		for (int i=0; i<numHorizontalTicks; i++)
			{
			float y = (float)i*pixelsPerTick_f;
			if (i == 6)
				y = lgPanelHeight_f/2.f;
			
			// draw horizontal tick marks, + and -, upper and lower panels
			
			offsetPaint.setColor(Color.BLACK);
			bgCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgUpperPanelZeroLine_f-y, lgPanelLeftMargin_f, lgUpperPanelZeroLine_f-y, offsetPaint);
			bgCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgUpperPanelZeroLine_f+y, lgPanelLeftMargin_f, lgUpperPanelZeroLine_f+y, offsetPaint);

			bgCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgLowerPanelZeroLine_f-y, lgPanelLeftMargin_f, lgLowerPanelZeroLine_f-y, offsetPaint);
			bgCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgLowerPanelZeroLine_f+y, lgPanelLeftMargin_f, lgLowerPanelZeroLine_f+y, offsetPaint);

			bgCanvas.drawLine(exPanelLeftMargin_f, exUpperPanelZeroLine_f-y, exPanelLeftMargin_f, exUpperPanelZeroLine_f-y, offsetPaint);
			bgCanvas.drawLine(exPanelLeftMargin_f, exUpperPanelZeroLine_f+y, exPanelLeftMargin_f, exUpperPanelZeroLine_f+y, offsetPaint);

			bgCanvas.drawLine(exPanelLeftMargin_f, exLowerPanelZeroLine_f-y, exPanelLeftMargin_f, exLowerPanelZeroLine_f-y, offsetPaint);
			bgCanvas.drawLine(exPanelLeftMargin_f, exLowerPanelZeroLine_f+y, exPanelLeftMargin_f, exLowerPanelZeroLine_f+y, offsetPaint);
			
			// draw horizontal grid lines, + and -, upper and lower panels
			
			if (i != (numHorizontalTicks-1))
				{
				offsetPaint.setColor(gridColor);
				bgCanvas.drawLine(lgPanelLeftMargin_f, lgUpperPanelZeroLine_f-y, lgPanelLeftMargin_f+lgPanelWidth_f, lgUpperPanelZeroLine_f-y, offsetPaint);
				bgCanvas.drawLine(lgPanelLeftMargin_f, lgUpperPanelZeroLine_f+y, lgPanelLeftMargin_f+lgPanelWidth_f, lgUpperPanelZeroLine_f+y, offsetPaint);

				bgCanvas.drawLine(lgPanelLeftMargin_f, lgLowerPanelZeroLine_f-y, lgPanelLeftMargin_f+lgPanelWidth_f, lgLowerPanelZeroLine_f-y, offsetPaint);
				bgCanvas.drawLine(lgPanelLeftMargin_f, lgLowerPanelZeroLine_f+y, lgPanelLeftMargin_f+lgPanelWidth_f, lgLowerPanelZeroLine_f+y, offsetPaint);

				bgCanvas.drawLine(exPanelLeftMargin_f, exUpperPanelZeroLine_f-y, exPanelLeftMargin_f+exPanelWidth_f, exUpperPanelZeroLine_f-y, offsetPaint);
				bgCanvas.drawLine(exPanelLeftMargin_f, exUpperPanelZeroLine_f+y, exPanelLeftMargin_f+exPanelWidth_f, exUpperPanelZeroLine_f+y, offsetPaint);

				bgCanvas.drawLine(exPanelLeftMargin_f, exLowerPanelZeroLine_f-y, exPanelLeftMargin_f+exPanelWidth_f, exLowerPanelZeroLine_f-y, offsetPaint);
				bgCanvas.drawLine(exPanelLeftMargin_f, exLowerPanelZeroLine_f+y, exPanelLeftMargin_f+exPanelWidth_f, exLowerPanelZeroLine_f+y, offsetPaint);
				}

			// label horizontal tick marks, + and -, upper and lower panels
			
			offsetPaint.setColor(Color.BLACK);
			final float densityScale = getResources().getDisplayMetrics().density;
			offsetPaint.setTextSize((densityScale>1.1f)?12.f:18.f);
			if ((numHorizontalTicks < 7) || (i != 5))
				{
				String tickLabel = Integer.valueOf((i!=6)?(i*tickInc):maxY).toString();
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				bgCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgUpperPanelZeroLine_f-y+tickLabelRect.height()/2.0f, offsetPaint);
				bgCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgLowerPanelZeroLine_f-y+tickLabelRect.height()/2.0f, offsetPaint);

				tickLabel = Integer.valueOf((i!=6)?(-i*tickInc):-maxY).toString();
				tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				bgCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgUpperPanelZeroLine_f+y+tickLabelRect.height()/2.0f, offsetPaint);
				bgCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgLowerPanelZeroLine_f+y+tickLabelRect.height()/2.0f, offsetPaint);
				}			
			}

		// draw vertical grid lines, + and -, upper and lower panels
		// extend every 4th to have as a tick mark

		int labelInc = 4;
		if (verticalOrientation && (numLeadGroups > 2)) 
				labelInc = 8;

		for (int i=0; i<=wrapChan; i++)
			{
			float x = ((float)i) * pixelsPerLGChannel_f;
			if ((i == 0) || (i == wrapChan))
				{
				offsetPaint.setColor(Color.BLACK);
				bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f+lgPanelHeight_f, lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f+lgPanelHeight_f+5.f, offsetPaint);
				bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f-5.f, lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f+lgPanelHeight_f, offsetPaint);
				}
			else
				{
				offsetPaint.setColor(gridColor);
				bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f, lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f+lgPanelHeight_f, offsetPaint);
				bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f, lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f+lgPanelHeight_f, offsetPaint);

				if ((i%4) == 0)
					{
					offsetPaint.setColor(Color.BLACK);
					bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f+lgPanelHeight_f, lgPanelLeftMargin_f+x, lgUpperPanelTopMargin_f+lgPanelHeight_f+5.f, offsetPaint);
					bgCanvas.drawLine(lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f-5.f, lgPanelLeftMargin_f+x, lgLowerPanelTopMargin_f, offsetPaint);
					}
				}

			// label vertical tick marks, between upper and lower panels

			if ((i%labelInc) == 0)
				{
				String tickLabel = Integer.valueOf(i%32).toString();
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				offsetPaint.setColor(Color.BLACK);
				bgCanvas.drawText(tickLabel, lgPanelLeftMargin_f+x-tickLabelRect.width()/2.f,
					(lgUpperPanelTopMargin_f+lgPanelHeight_f+lgLowerPanelTopMargin_f)/2.f+tickLabelRect.height()/2.f, offsetPaint);
				}
			}			

		// ex1-4, ex5-8
		
		for (int i=0; i<=4; i++)
			{
			offsetPaint.setColor(gridColor);
			float x = ((float)i) * pixelsPerEXChannel_f;
			if ((i == 0) || (i == 4))
				{
				offsetPaint.setColor(Color.BLACK);
				bgCanvas.drawLine(exPanelLeftMargin_f+x, exUpperPanelTopMargin_f+exPanelHeight_f, exPanelLeftMargin_f+x, exUpperPanelTopMargin_f+exPanelHeight_f+5.f, offsetPaint);
				bgCanvas.drawLine(exPanelLeftMargin_f+x, exLowerPanelTopMargin_f-5.f, exPanelLeftMargin_f+x, exLowerPanelTopMargin_f+exPanelHeight_f, offsetPaint);
				}
			else
				{
				offsetPaint.setColor(gridColor);
				bgCanvas.drawLine(exPanelLeftMargin_f+x, exUpperPanelTopMargin_f, exPanelLeftMargin_f+x, exUpperPanelTopMargin_f+exPanelHeight_f, offsetPaint);
				bgCanvas.drawLine(exPanelLeftMargin_f+x, exLowerPanelTopMargin_f, exPanelLeftMargin_f+x, exLowerPanelTopMargin_f+exPanelHeight_f, offsetPaint);
				if ((i%2) == 0)
					{
					offsetPaint.setColor(Color.BLACK);
					bgCanvas.drawLine(exPanelLeftMargin_f+x, exUpperPanelTopMargin_f+exPanelHeight_f, exPanelLeftMargin_f+x, exUpperPanelTopMargin_f+exPanelHeight_f+5.f, offsetPaint);
					bgCanvas.drawLine(exPanelLeftMargin_f+x, exLowerPanelTopMargin_f-5.f, exPanelLeftMargin_f+x, exLowerPanelTopMargin_f, offsetPaint);
					}
				}

			exRectangles[0] = new RectF(exPanelLeftMargin_f, exUpperPanelTopMargin_f, exPanelLeftMargin_f+exPanelWidth_f, exUpperPanelTopMargin_f+exPanelHeight_f);
			exRectangles[1] = new RectF(exPanelLeftMargin_f, exLowerPanelTopMargin_f, exPanelLeftMargin_f+exPanelWidth_f, exLowerPanelTopMargin_f+exPanelHeight_f);
			
			// label vertical tick marks, between upper and lower panels

			if ((i%2) == 0)
				{
				offsetPaint.setColor(Color.BLACK);
				String tickLabel = Integer.valueOf(i%4).toString();
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				bgCanvas.drawText(tickLabel, exPanelLeftMargin_f+x-tickLabelRect.width()/2.f,
					(exUpperPanelTopMargin_f+exPanelHeight_f+exLowerPanelTopMargin_f)/2.f+tickLabelRect.height()/2.f, offsetPaint);
				}
			}			

		// label lead groups
		
		offsetPaint.setColor(Color.BLACK);
		float prevTextSize = offsetPaint.getTextSize();
		int lgPerPanel = (numLeadGroups+1)/2;
		for (int lg=0; lg<numLeadGroups; lg++)
			{
			float x = (((float)(lg%lgPerPanel)) * 32.f + 16.f) * pixelsPerLGChannel_f;

			String lgLabel = "ABCDEFGH".substring(lg, lg+1);
			Rect lgLabelRect = new Rect(0, 0, 1, 1);
			offsetPaint.getTextBounds(lgLabel, 0, lgLabel.length(), lgLabelRect);
			if (lg < (numLeadGroups+1)/2)
				{
				bgCanvas.drawText(lgLabel, lgPanelLeftMargin_f+x-lgLabelRect.width()/2.f, lgUpperPanelTopMargin_f/2.f+lgLabelRect.height()/2.f, offsetPaint);
				}
			else
				{
				bgCanvas.drawText(lgLabel, lgPanelLeftMargin_f+x-lgLabelRect.width()/2.f, height_f-lgLowerPanelBottomMargin_f/2.f+lgLabelRect.height()/2.f, offsetPaint);
				}
			}

		offsetPaint.setTextSize(prevTextSize);

		// label ex leads
		
		offsetPaint.setColor(Color.BLACK);
		for (int ex=0; ex<2; ex++)
			{
			float x = exPanelWidth_f/2.f;;

			String exLabel = "Ex1-4Ex5-8".substring(ex*5, ex*5+5);
			Rect exLabelRect = new Rect(0, 0, 1, 1);
			offsetPaint.getTextBounds(exLabel, 0, exLabel.length(), exLabelRect);
			if (ex == 0)
				bgCanvas.drawText(exLabel, Math.max(exPanelLeftMargin_f+x-exLabelRect.width()/2.f,0.f), exUpperPanelTopMargin_f/2.f+exLabelRect.height()/2.f, offsetPaint);
			else
				bgCanvas.drawText(exLabel, Math.max(exPanelLeftMargin_f+x-exLabelRect.width()/2.f,0.f), height_f-exLowerPanelBottomMargin_f/2.f+exLabelRect.height()/2.f, offsetPaint);
			}
		}// createBackgroundBitmap()
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
		{
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);

		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int heightSize = MeasureSpec.getSize(heightMeasureSpec);

		int chosenWidth = chooseDimension(widthMode, widthSize);
		int chosenHeight = chooseDimension(heightMode, heightSize);

		setMeasuredDimension(chosenWidth, chosenHeight);
		}

	private int chooseDimension(int mode, int size)
		{
		if (mode == MeasureSpec.AT_MOST || mode == MeasureSpec.EXACTLY)
			return size;
		else // (mode == MeasureSpec.UNSPECIFIED)
			return getPreferredSize();
		}

	// in case there is no size specified
	private int getPreferredSize()
		{
		return 300;
		}

	public void setChannelToPlot(int chanOffset)
		// chanOffset counts from 0
		{
		if (chanOffset != showAbsChan)
			{
			showAbsChan = chanOffset;
		
			remoteNumChannelsXfr = 0;			// force new valid channel array
			}
		}

	public void onSaveInstanceState(Bundle outState)
		{
		outState.putInt("lobgv_showAbsChan", showAbsChan);
		outState.putInt("lobgv_ampMax",  ampMax);
	
		if (bgImage != null)
			{
			bgImage.recycle();
			bgImage = null;
			}	
		}

	public void onRestoreInstanceState(Bundle inState)
		{
		if (inState != null)
			{
			Set<String> keys = inState.keySet();

			if (keys.contains("lobgv_showAbsChan"))
				showAbsChan = inState.getInt("lobgv_showAbsChan");

			if (keys.contains("lobgv_ampMax"))
				ampMax = inState.getInt("lobgv_ampMax");
			}	
		}

	public void suspendXfrUpdates()
		{
		suspendXfrUpdates = true;
		}

	public void resumeXfrUpdates()
		{
		suspendXfrUpdates = false;
		}
	
	// following added to satisfy lint
	
	public LeadOffsetByGraphView(Context context)
		{
	    super(context);
		}
	
	public LeadOffsetByGraphView(Context context, AttributeSet attrs)
		{
	    super(context, attrs);
		}
	
	}// LeadOffsetByGraphView class