package com.biosemi.bschannelviewer;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Set;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;

public class LeadOffsetByLayoutView extends View
	{	
	// variables that must be saved/restored when orientation changes 
	
	private int	showAbsChan;
	private int	ampMax;
	private int	rotateDegrees;
	private boolean	numericLabels;
	
	private float	magXX;
	private float	magYY;

	private float	scrollXOffset;
	private float	scrollYOffset;

	// other variables

	private Bitmap	bgImage;
	private RemoteAcquisitionFragment	remoteAcquisitionFragment;
	private int	numLGChannels;
	private int[]	sampleBuffer;
	private int	sampleBufferSizeInts;
	private AcquisitionControlActivity	acquisitionControlActivity;

	private PointF[]	leadPositions;
	private Point[]	leadPositionsOnScreen;
	private int[]	leadCircleRadiusOnScreen;
	private float	electrodeCircleRadius;
	private float  magX;
	private float  magY;
	private GestureDetector gestureDetector;
	private float	electrodeMinX;
	private float	electrodeMaxX;
	private float	electrodeMinY;
	private float	electrodeMaxY;
	private Paint	offsetPaint;
	private int	headCornerX;
	private int	headCornerY;
	private float	vertOrient_magX;
	private float	vertOrient_magY;
	private float	vertOrient_scrollXOffset;
	private float	vertOrient_scrollYOffset;
	private float	horizOrient_magX;
	private float	horizOrient_magY;
	private float	horizOrient_scrollXOffset;
	private float	horizOrient_scrollYOffset;
	private boolean	forVerticalOrientation;
	private String[]	leadLabels;
	private int	labelCornerX;
	private int	labelCornerY;
	
	private long	lastPosition;
	private int	remoteNumChannels;
	private int	remoteNumChannelsXfr;
	private int	remoteSampleRate;
	private int originX;
	private int originY;
	private boolean[]	channelIsValid;
	private boolean	suspendXfrUpdates;
	private boolean verticalOrientation;
	
	public LeadOffsetByLayoutView(Context context)
		{
		super(context);
		// TODO Auto-generated constructor stub
		}

	public LeadOffsetByLayoutView(Context context, RemoteAcquisitionFragment ravf, AcquisitionControlActivity aca, Bundle inState)
		{
		super(context);
		acquisitionControlActivity = aca;
		remoteAcquisitionFragment = ravf;
		
		// initialize all saved state variables
	
		showAbsChan = acquisitionControlActivity.getChannelToPlot();
		ampMax = 262;;
		rotateDegrees = 180;	// head facing down
		numericLabels = true;
		magXX = 1.0f;
		magYY = 1.0f;
		scrollXOffset = 0.f;
		scrollYOffset = 0.f;

		// restore any saved state
		if (inState != null)
			onRestoreInstanceState(inState);
		
		sampleBufferSizeInts = -1;
		suspendXfrUpdates = false;
	
		offsetPaint = new Paint();

		vertOrient_magX = 1.0f;
		vertOrient_magY = 1.0f;
		vertOrient_scrollXOffset = 0.0f;
		vertOrient_scrollYOffset = 0.0f;
		horizOrient_magX = 1.0f;
		horizOrient_magY = 1.0f;
		horizOrient_scrollXOffset = 0.0f;
		horizOrient_scrollYOffset = 0.0f;
	
		boolean verticalOrientation = false;
		if (acquisitionControlActivity.getResources().getConfiguration().orientation ==  Configuration.ORIENTATION_PORTRAIT)
			verticalOrientation = true;
	
		if (verticalOrientation)
			{
			magX = vertOrient_magX;
			magY = vertOrient_magY;
			scrollXOffset = vertOrient_scrollXOffset;
			scrollYOffset = vertOrient_scrollYOffset;
			forVerticalOrientation = true;
			}
		else
			{
			magX = horizOrient_magX;
			magY = horizOrient_magY;
			scrollXOffset = horizOrient_scrollXOffset;
			scrollYOffset = horizOrient_scrollYOffset;
			forVerticalOrientation = false;
			}
	
		updateDisplay();

		gestureDetector = new GestureDetector(context, new SimpleOnGestureListener()
			{
			// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true
			
			@Override
			public boolean onDown(MotionEvent evt)
				{
				// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true
				return true;
				}

			@Override
			public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
				{
				boolean result = false;
			
				// scroll only when magnified
				if (magXX > 1.5f)
					{
					// scroll in the larger direction
					if (Math.abs(distanceX) > Math.abs(distanceY))
						scrollXOffset -= distanceX;
					else
						scrollYOffset -= distanceY;
	
					invalidate();
				
					result = true;
					}
			
				return result;
				}// onScroll()
		
			@Override
			public boolean onDoubleTap(MotionEvent evt)
				{
				boolean result = false;

				if (magXX < 1.5f)
					{
					magXX = 2.0f;
					magYY = 2.0f;
					}
				else
					{
					magXX = 1.0f;
					magYY = 1.0f;
				
					// scroll only when magnified
					scrollXOffset = 0;
					scrollYOffset = 0;
					}
			
				invalidate();
				result = true;
			
				return result;
				}// onDoubleTap()
			
			@Override
			public boolean onSingleTapConfirmed(MotionEvent evt)
				{
				boolean result = false;

				// monitor only when doing single touch
				if (evt.getPointerCount() > 1)
					return false;

				int pointerIndex = evt.getActionIndex();
				int x = (int)evt.getX(pointerIndex);
				int y = (int)evt.getY(pointerIndex);

				// check for head rotate request
				if ((magXX < 1.5f) && (x > headCornerX) && (y < headCornerY))
						{
						rotateDegrees = 180 - rotateDegrees;	// flip head up (0) <--> head down (180)
						invalidate();
						
						result = true;
						}

				// check for alpha/numeric label request
				else if ((magXX < 1.5f) && (leadLabels != null) && (x > labelCornerX) && (y > labelCornerY))
						{
						numericLabels = !numericLabels;
						invalidate();

						result = true;
						}
				
				// find nearest electrode
				else
					{
					int minChan = 0;
					int xDistance = x - leadPositionsOnScreen[0].x;
					int yDistance = y - leadPositionsOnScreen[0].y;
					int minDistanceSquared = xDistance*xDistance + yDistance*yDistance;
					for (int i=1; i<(numLGChannels); i++)
						{
						xDistance = x - leadPositionsOnScreen[i].x;
						yDistance = y - leadPositionsOnScreen[i].y;
						int distanceSquared = xDistance*xDistance + yDistance*yDistance;
						if (distanceSquared < minDistanceSquared)
							{
							minDistanceSquared = distanceSquared;
							minChan = i;
							}
						}
					if (minDistanceSquared < 4*(leadCircleRadiusOnScreen[minChan]*leadCircleRadiusOnScreen[minChan]))
						{
						acquisitionControlActivity.setChannelToPlot(2+minChan);

						result = true;
						}
					}
				
				return result;
				}// onSingleTapConfirmed()

			});// SimpleOnGestureListener()

		setOnTouchListener(new OnTouchListener()
			{
			@Override
			public boolean onTouch(View v, MotionEvent evt)
				{
			return gestureDetector.onTouchEvent(evt);
				}
			});// OnTouchListener()
	
		}// LeadOffsetByLayoutView() class constructor

	private void updateDisplay()
		{
		/*
		 * driven by either postDelayed run requests scheduled below or onVisibilitycChanged calls;
		 * tracks "ring buffer" position by getSampleBufferSeam calls
		*/
		long position = remoteAcquisitionFragment.getSampleBufferSeam();

		if (position != lastPosition)
			{
			if (position >= 0)
				{
				lastPosition = position;

				// samples are now being read so get remote values if they are not already set

				if (remoteNumChannels == 0)
					{
					remoteNumChannels = remoteAcquisitionFragment.getRemoteNumChannels();

					if (remoteNumChannels > 0)
						{
						numLGChannels = ((remoteNumChannels-2)/32)*32;

						leadPositions = getLeadPositions(numLGChannels);
						leadPositionsOnScreen = new Point[numLGChannels+2];		// +2 for cms, drl
						leadCircleRadiusOnScreen = new int[numLGChannels+2];

						leadLabels = getLeadLabels(numLGChannels);
						}
					}	

				if (remoteNumChannelsXfr == 0)
					{
					remoteNumChannelsXfr = remoteAcquisitionFragment.getRemoteNumChannelsXfr();
			
					// setup valid channel array
					int[] channelXfrVector = remoteAcquisitionFragment.getChannelXfrVector();
					if (channelXfrVector != null)
						{
						channelIsValid = new boolean[remoteNumChannels];
			
						for (int i=0; i<remoteNumChannels; i++)
							channelIsValid[i] = false;
			
						for (int i=0; i<remoteNumChannelsXfr; i++)
							channelIsValid[channelXfrVector[i]] = true;
						}
					}
		
				if (remoteSampleRate == 0)
					remoteSampleRate = remoteAcquisitionFragment.getRemoteSampleRate();

				if ((isShown() && (suspendXfrUpdates == false)))
					invalidate();
		
				}// position >= 0
	
			// re-schedule in 1 second
			postDelayed(new Runnable()
				{
				@Override
				public void run()
					{
					updateDisplay();
					}
				}, 1000);
			}// position != lastPosition
		
		}// ipdateDisplay()

	@Override
	protected void onVisibilityChanged(View v, int visibility)
		{
		if (visibility != GONE)
			updateDisplay();
		}

	@Override
	protected void onDraw(Canvas canvas)
		{
		if (remoteNumChannels == 0)
			return;

		if (verticalOrientation)
			{
			if (!forVerticalOrientation)
				{
				magX = vertOrient_magX;
				magY = vertOrient_magY;
				scrollXOffset = vertOrient_scrollXOffset;
				scrollYOffset = vertOrient_scrollYOffset;
				forVerticalOrientation = true;
				}
			}
		else
			if (forVerticalOrientation)
				{
				magX = horizOrient_magX;
				magY = horizOrient_magY;
				scrollXOffset = horizOrient_scrollXOffset;
				scrollYOffset = horizOrient_scrollYOffset;
				forVerticalOrientation = false;
				}

		// get view dimensions
		int height = getHeight();
		int width = getWidth();
		float width_f = (float)width;
		float height_f = (float)height;
	
		int numDrawChannels = (remoteNumChannels-2)/32*32 + 2;		// drop sync and status and add drl,cms
	
		// flood fill the background
	
		int frameColor = Color.rgb(0x95, 0x8d, 0xb6);
		canvas.drawColor(frameColor);
	
		long position = remoteAcquisitionFragment.getSampleBufferSeam();

		if (position < 0)
			return;		// no samples yet
		
		int seam = (int)(position&0xffffffff);
	
		if (sampleBufferSizeInts == -1)
			{
			sampleBuffer = remoteAcquisitionFragment.getSampleBuffer();
			sampleBufferSizeInts = remoteAcquisitionFragment.getSampleBufferSizeInts();
			}

		int lastTupleIndex = seam - remoteNumChannels;
		if (lastTupleIndex < 0)
			lastTupleIndex += sampleBufferSizeInts;
			
		offsetPaint.setStrokeWidth(0.0f);
		offsetPaint.setColor((ampMax==262)?Color.RED:Color.BLUE);	
		offsetPaint.setStyle(Paint.Style.STROKE);

		final float densityScale = getResources().getDisplayMetrics().density;
		offsetPaint.setTextSize((densityScale>1.1f)?12.f:18.f);
		
		float yZeroLine = height_f/2.f;
		float xZeroLine = width_f/2.f;

		float electrodeSpaceMaxX = width_f - 20.f; 
		float electrodeSpaceMaxY = height_f - 20.f; 

		float yOffset = electrodeSpaceMaxY/2.f;
		float xOffset = electrodeSpaceMaxX/2.0f;
	
		xOffset += originX;
		yOffset += originY;
	
		float fillSpaceMagX = electrodeSpaceMaxX/(electrodeMaxX-electrodeMinX);
		float fillSpaceMagY = electrodeSpaceMaxY/(electrodeMaxY-electrodeMinY);
	
		// connect electrode centers
	
		float xCenter = 0.f;
		float yCenter = 0.f;
	
		float lastXCenter = 0.f;
		float lastYCenter = 0.f;
		int numChan = leadPositions.length - 2;			// don't connect cms, drl
		offsetPaint.setColor(Color.BLACK);
		offsetPaint.setStrokeWidth(3.0f);
		for (int chan=0; chan<numChan; chan++)
			{
			if (rotateDegrees == 0)
				{// head facing up
				xCenter = xZeroLine+((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine+((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}
			else
				{// head facing down
				xCenter = xZeroLine-((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine-((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}

			xCenter *= magXX;
			yCenter *= magYY;
		
			if ((chan%32) != 0)
				canvas.drawLine(lastXCenter, lastYCenter, xCenter, yCenter, offsetPaint);

			lastXCenter = xCenter;
			lastYCenter = yCenter;
			}
	
		// draw head outline oval

		// define enclosing rectangle (left, top, right, bottom)
		RectF headRectF = new RectF(
			xZeroLine+(-xOffset)*magX+scrollXOffset,
			yZeroLine+(-yOffset)*magY+scrollYOffset,
			xZeroLine+((electrodeMaxX-electrodeMinX)*fillSpaceMagX-xOffset)*magX*magXX+scrollXOffset,
			yZeroLine+((electrodeMaxY-electrodeMinY)*fillSpaceMagY-yOffset)*magY*magYY+scrollYOffset);

		offsetPaint.setColor(Color.GREEN);
		offsetPaint.setStyle(Paint.Style.STROKE);

		canvas.drawOval(headRectF, offsetPaint);

		// draw electrode circles

		electrodeCircleRadius = 15.f;
		offsetPaint.setStyle(Paint.Style.FILL);
		offsetPaint.setStrokeWidth(0.0f);
	
		// draw all electrode circles, include cms and drl
		
		for (int chan=0; chan<numDrawChannels; chan++)
			{
			if (rotateDegrees == 0)
				{
				xCenter = xZeroLine+((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine+((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}
			else
				{
				xCenter = xZeroLine-((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine-((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}

			xCenter *= magXX;
			yCenter *= magYY;

			// determine size needed to contain the electrode's label
		
			String labelBuf;
			if (numericLabels)
				{
				if (chan >= numDrawChannels-2)
					labelBuf = "CMSDRL".substring((chan-(numDrawChannels-2))*3, (chan-(numDrawChannels-2))*3+3);
				else
					{
					int leadGroup = chan/32;
					labelBuf = "ABCDEFGH".substring(leadGroup, leadGroup+1)+((chan%32)+1);
					}
				}
			else
				labelBuf = leadLabels[chan];
			
			Rect tickLabelRect = new Rect(0, 0, 1, 1);
			offsetPaint.getTextBounds(labelBuf, 0, labelBuf.length(), tickLabelRect);
		
			// radius is half height or width of label, whichever is bigger
			electrodeCircleRadius = ((tickLabelRect.width()>tickLabelRect.height())?tickLabelRect.width():tickLabelRect.height())/2.f + 2.f;

			if ((chan < numDrawChannels-2) && (2+chan == showAbsChan))
				offsetPaint.setColor(Color.GREEN);
			else if ((chan >= numDrawChannels-2) || !channelIsValid[2+chan])
				offsetPaint.setColor(Color.BLACK);
			else
				offsetPaint.setColor(Color.WHITE);

			canvas.drawCircle(xCenter, yCenter, electrodeCircleRadius, offsetPaint);
		
			leadPositionsOnScreen[chan] = new Point((int)xCenter, (int)yCenter);
			leadCircleRadiusOnScreen[chan] = (int)electrodeCircleRadius;
			}

		// insert electrode numbers
	
		offsetPaint.setStyle(Paint.Style.STROKE);
		for (int chan=0; chan<numDrawChannels; chan++)
			{
			if (rotateDegrees == 0)
				{
				xCenter = xZeroLine+((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine+((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}
			else
				{
				xCenter = xZeroLine-((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
				yCenter = yZeroLine-((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
				}

			xCenter *= magXX;
			yCenter *= magYY;
		
			if ((chan < numDrawChannels-2) && (2+chan == showAbsChan))
				offsetPaint.setColor(Color.BLACK);
			else if ((chan >= numDrawChannels-2) || !channelIsValid[2+chan])
				offsetPaint.setColor(Color.WHITE);
			else
				offsetPaint.setColor(Color.BLACK);
		
			String labelBuf;
			if (numericLabels)
				{
				if (chan >= numDrawChannels-2)
					labelBuf = "CMSDRL".substring((chan-(numDrawChannels-2))*3, (chan-(numDrawChannels-2))*3+3);
				else
					{
					int leadGroup = chan/32;
					labelBuf = "ABCDEFGH".substring(leadGroup, leadGroup+1)+((chan%32)+1);
					}
				}
			else
				labelBuf = leadLabels[chan];
			
			Rect tickLabelRect = new Rect(0, 0, 1, 1);
			offsetPaint.getTextBounds(labelBuf, 0, labelBuf.length(), tickLabelRect);
			canvas.drawText(labelBuf, xCenter-tickLabelRect.width()/2.f, yCenter+tickLabelRect.height()/2.0f, offsetPaint);
			}

		// flag electrodes out of range
	
		offsetPaint.setColor(Color.RED);
		offsetPaint.setStrokeWidth(2.0f);
		for (int chan=0; chan<numDrawChannels-2; chan++)
			{
			if (channelIsValid[2+chan])
				{
				int samp = 0;
				if (lastTupleIndex+2+chan < sampleBufferSizeInts)
					samp = sampleBuffer[lastTupleIndex+2+chan];
				else
					samp = sampleBuffer[lastTupleIndex+2+chan-sampleBufferSizeInts];
			
				float sample = (float)samp/31.25f/1000.f;		// mvolts
				float pcOfMax = Math.abs(sample/(float)ampMax);
				if (pcOfMax > 1.f)
					pcOfMax = 1.f;
				int colorPc = ((int)(255. * (1.f-pcOfMax))) & 255;
				if (ampMax == 262)
					offsetPaint.setColor(Color.rgb(255,  colorPc,  colorPc));	// shades of red
				else
					offsetPaint.setColor(Color.rgb(colorPc,  colorPc, 255));	// shades of blue

				if (rotateDegrees == 0)
					{
					xCenter = xZeroLine+((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
					yCenter = yZeroLine+((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
					}
				else
					{
					xCenter = xZeroLine-((leadPositions[chan].x-electrodeMinX)*fillSpaceMagX-xOffset)*magX+scrollXOffset;
					yCenter = yZeroLine-((leadPositions[chan].y-electrodeMinY)*fillSpaceMagY-yOffset)*magY+scrollYOffset;
					}

				xCenter *= magXX;
				yCenter *= magYY;
		
				String labelBuf;
				if (numericLabels)
					{
					int leadGroup = chan/32;
					labelBuf = "ABCDEFGH".substring(leadGroup, leadGroup+1)+((chan%32)+1);
					}
				else
					labelBuf = leadLabels[chan];
				
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(labelBuf, 0, labelBuf.length(), tickLabelRect);
		
				// radius is half height or width of label, whichever is bigger
				electrodeCircleRadius = ((tickLabelRect.width()>tickLabelRect.height())?tickLabelRect.width():tickLabelRect.height())/2.f + 1.f;

				canvas.drawCircle(xCenter, yCenter, electrodeCircleRadius+1.f, offsetPaint);
				}
			}
	
		if (magXX < 1.5f)
			{
			// draw head orientation in upper right corner
	
			offsetPaint.setColor(Color.GREEN);
			offsetPaint.setStrokeWidth(2.0f);

			xCenter = width_f - width_f*0.05f;
			yCenter = height_f*0.05f;
			float headRadius = ((width_f < height_f)?width_f:height_f)*0.03f;

			// draw nose
			if (rotateDegrees == 0)
				{
				canvas.drawLine(xCenter-headRadius*0.5f, yCenter-headRadius*0.5f, xCenter, yCenter-headRadius*1.4f, offsetPaint);
				canvas.drawLine(xCenter+headRadius*0.5f, yCenter-headRadius*0.5f, xCenter, yCenter-headRadius*1.4f, offsetPaint);
				}
			else
				{
				canvas.drawLine(xCenter-headRadius*0.5f, yCenter+headRadius*0.5f, xCenter, yCenter+headRadius*1.4f, offsetPaint);
				canvas.drawLine(xCenter+headRadius*0.5f, yCenter+headRadius*0.5f, xCenter, yCenter+headRadius*1.4f, offsetPaint);
				}
		
			// draw head
			canvas.drawCircle(xCenter, yCenter, headRadius, offsetPaint);
	
			headCornerX = (int)(xCenter - headRadius*4);
			headCornerY = (int)(yCenter + headRadius*4);

			if (leadLabels != null)
				{
				// setup alpha/numeric label request corner
	
				offsetPaint.setColor(Color.WHITE);
				offsetPaint.setStrokeWidth(2.0f);

				xCenter = width_f - width_f*0.05f;
				yCenter = height_f - height_f*0.05f;
		
				offsetPaint.setColor(Color.BLACK);
				offsetPaint.setStrokeWidth(0.0f);

				String labelBuf = numericLabels?"ABC":"123";
				Rect labelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(labelBuf, 0, labelBuf.length(), labelRect);
			
				// radius is half height or width of label, whichever is bigger
				float labelRadius = ((labelRect.width()>labelRect.height())?labelRect.width():labelRect.height())/2.f + 2.f;
				canvas.drawCircle(xCenter, yCenter, labelRadius, offsetPaint);
		
				canvas.drawText(labelBuf, xCenter-labelRect.width()/2.f, yCenter+labelRect.height()/2.0f, offsetPaint);
	
				labelCornerX = (int)(xCenter - labelRadius*4);
				labelCornerY = (int)(yCenter - labelRadius*4);
				}
			}// magXX < 1.5f

		// save variables that change with orientation
	
		if (verticalOrientation)
			{
			vertOrient_magX = magX;
			vertOrient_magY = magY;
			vertOrient_scrollXOffset = scrollXOffset;
			vertOrient_scrollYOffset = scrollYOffset;
			}
		else
			{
			horizOrient_magX = magX;
			horizOrient_magY = magY;
			horizOrient_scrollXOffset = scrollXOffset;
			horizOrient_scrollYOffset = scrollYOffset;
			}
	
		}// onDraw()

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
		{
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);

		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int heightSize = MeasureSpec.getSize(heightMeasureSpec);

		int chosenWidth = chooseDimension(widthMode, widthSize);
		int chosenHeight = chooseDimension(heightMode, heightSize);

		setMeasuredDimension(chosenWidth, chosenHeight);
		}

	private int chooseDimension(int mode, int size)
		{
		if (mode == MeasureSpec.AT_MOST || mode == MeasureSpec.EXACTLY)
			return size;
		else // (mode == MeasureSpec.UNSPECIFIED)
			return getPreferredSize();
		}

	// in case there is no size specified
	private int getPreferredSize()
		{
		return 300;
		}

	public PointF[] getLeadPositions(int nl)
		{
		InputStream is = null;
	
		int id = getResources().getIdentifier("cap_"+nl+"_layout_medium", "raw", acquisitionControlActivity.getPackageName());
		if (id > 0)
			is = acquisitionControlActivity.getResources().openRawResource(id);
		if ((is == null) && (nl <= 64))
			{
			int inputFileResource = R.raw.cap_64_layout_medium;
			is = acquisitionControlActivity.getResources().openRawResource(inputFileResource);
			}
		else if ((is == null) && (nl <= 256))
			{
			int inputFileResource = R.raw.cap_256_layout_medium;
			is = acquisitionControlActivity.getResources().openRawResource(inputFileResource);
			}
		if (is == null) return null;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);

		String aline="";
		int xCoord;
		int yCoord;
		electrodeMinX = 9999.f;
		electrodeMaxX = 0.f;
		electrodeMinY = 9999.f;
		electrodeMaxY = 0.f;

		nl += 2;									// +2 for cms, drl
		PointF[] leadPoints = new PointF[nl];
		int minX = 999999;
		int maxX = 0;
		int minY = 999999;
		int maxY = 0;
	
		// read nl electrode centers, in format "x1,y1 x2,y2 ..."
		// x,y separated by a comma, pairs separated by a space, any number of pairs per line  
		// lines starting with '#' are comments
		for (int ind=0; ind<nl; )
			{
			try
				{
				aline = br.readLine();
				}
			catch (Exception e)
				{
				System.out.println("Exception: "+e.getMessage());
				System.out.println("On reading file 'leadPositions'");

				try
					{
					is.close();
					}
				catch (Exception ce)
					{}
				
				is = null;
				if (ind <= 0)
					return null;
				}	

			if ((is == null) || (aline == null) || (aline.length() == 0))
				break;

			if (aline.startsWith("#"))
				continue;			// comment line

			for (;;)
				{
				aline = aline.trim();
				if (aline.length() == 0)
					break;			// next line
				
				String intBuf;

				int commax = aline.indexOf(",");
				if (commax >= 0)
					intBuf = aline.substring(0, aline.indexOf(","));
				else
					intBuf = aline;
				xCoord = (intBuf.length() > 0)?Integer.parseInt(intBuf):0;
				if (commax >= 0)
					aline = aline.substring(commax+1);
				else
					aline = "";

				int spacex = aline.indexOf(" ");
				if (spacex >= 0)
					intBuf = aline.substring(0, aline.indexOf(" "));
				else
					intBuf = aline;
				yCoord = (intBuf.length() > 0)?Integer.parseInt(intBuf):0;
				if (spacex >= 0)
					aline = aline.substring(spacex);
				else
					aline = "";
				
				leadPoints[ind++] = new PointF((float)xCoord, (float)yCoord);
				
				// track min,max coordinates
				
				if (xCoord < minX)
					minX = xCoord;
				else if (xCoord > maxX)
					maxX = xCoord;
				
				if (yCoord < minY)
					minY = yCoord;
				else if (yCoord > maxY)
					maxY = yCoord;
				} // finished 1 x,y pair
			} // finished one line

		// min/max are the electrode centers
		// add a margin on all sides
	
		electrodeMinX = (float)(minX - 20);
		electrodeMinY = (float)(minY - 20);
		electrodeMaxX = (float)(maxX + 20);
		electrodeMaxY = (float)(maxY + 20);

		if (is != null)
			{
			try
				{
				is.close();
				}
			catch (Exception ce)
				{}
			is = null;
			}
	
		return leadPoints;
		}// getLeadPositions()

	public String[] getLeadLabels(int nl)
		{
		InputStream is = null;
	
		int id = getResources().getIdentifier("cap_"+nl+"_layout_medium_labels", "raw", acquisitionControlActivity.getPackageName());
		if (id > 0)
			is = acquisitionControlActivity.getResources().openRawResource(id);
		if (is == null) return null;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);

		String aline="";
		nl += 2;									// +2 for cms, drl
		String[] leadLabels = new String[nl];
	
		// read nl electrode labels, in format "l1 l2 ..."
		// labels separated by a space, any number of labels per line  
		// lines starting with '#' are comments
		for (int ind=0; ind<nl; )
			{
			try
				{
				aline = br.readLine();
				}
			catch (Exception e)
				{
				System.out.println("Exception: "+e.getMessage());
				System.out.println("On reading file 'leadPositions'");

				try
					{
					is.close();
					}
				catch (Exception ce)
					{}
				is = null;
				if (ind <= 0)
					return null;
				}	

			if ((is == null) || (aline == null) || (aline.length() == 0))
				break;

			if (aline.startsWith("#"))
				continue;			// comment line

			for (;;)
				{
				aline = aline.trim();
				if (aline.length() == 0)
					break;			// next line
				
				String intBuf;

				int spacex = aline.indexOf(" ");
				if (spacex >= 0)
					intBuf = aline.substring(0, aline.indexOf(" "));
				else
					intBuf = aline;

				if (spacex >= 0)
					aline = aline.substring(spacex);
				else
					aline = "";
				
				leadLabels[ind++] = intBuf;
				
				} // finished 1 label
			} // finished one line

		if (is != null)
			{
			try
				{
				is.close();
				}
			catch (Exception ce)
				{}
			is = null;
			}
	
		return leadLabels;
		}// getLeadLabels()

	public void onSaveInstanceState(Bundle outState)
		{
		outState.putInt("loblv_showAbsChan", showAbsChan);
		outState.putInt("loblv_ampMax", ampMax);
		outState.putInt("rotateDegrees", rotateDegrees);
		outState.putBoolean("numericLabels", numericLabels);
	
		outState.putFloat("loblv_magXX", magXX);
		outState.putFloat("loblv_magYY", magYY);

		outState.putFloat("loblv_scrollXOffset", scrollXOffset);
		outState.putFloat("loblv_scrollYOffset", scrollYOffset);
	
		if (bgImage != null)
			{
			bgImage.recycle();
			bgImage = null;
			}
		}// onSaveInstanceState()

	public void onRestoreInstanceState(Bundle inState)
		{
		if (inState != null)
			{
			Set<String> keys = inState.keySet();

			if (keys.contains("loblv_showAbsChan"))
				showAbsChan = inState.getInt("loblv_showAbsChan");

			if (keys.contains("loblv_ampMax"))
				ampMax = inState.getInt("loblv_ampMax");

			if (keys.contains("rotateDegrees"))
				rotateDegrees = inState.getInt("rotateDegrees");

			if (keys.contains("numericLabels"))
				numericLabels = inState.getBoolean("numericLabels");

			if (keys.contains("loblv_magXX"))
				magXX = inState.getFloat("loblv_magXX");

			if (keys.contains("loblv_magYY"))
				magYY = inState.getFloat("loblv_magYY");

			if (keys.contains("loblv_scrollXOffset"))
				scrollXOffset = inState.getFloat("loblv_scrollXOffset");
		
			if (keys.contains("loblv_scrollYOffset"))
				scrollYOffset = inState.getFloat("loblv_scrollYOffset");
			}
		}// onRestoreInstanceState()

	public void setChannelToPlot(int chanOffset)
		// chanOffset counts from 0
		{
		if (chanOffset != showAbsChan)
			{
			showAbsChan = chanOffset;
		
			remoteNumChannelsXfr = 0;			// force new channel valid array
			}
		}

	public void suspendXfrUpdates()
		{
		suspendXfrUpdates = true;
		}

	public void resumeXfrUpdates()
		{
		suspendXfrUpdates = false;
		}
	}// LeadOffsetByLayoutView class