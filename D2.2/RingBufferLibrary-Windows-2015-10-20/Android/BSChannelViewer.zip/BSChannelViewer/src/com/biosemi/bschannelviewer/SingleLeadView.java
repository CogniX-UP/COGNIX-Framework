package com.biosemi.bschannelviewer;

import java.lang.ref.WeakReference;
import java.util.Set;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Toast;

public class SingleLeadView extends View
	{	
	// variables that must be saved/restored when orientation changes 
	
	private int	ampMax;
	private volatile int	magTime;
	private long lastPosition_updateDisplay;

	// other variables
	
	private volatile Bitmap	viewImageBackgroundForOnDraw;
	private Bitmap	viewImageBackground;

	private RemoteAcquisitionFragment	remoteAcquisitionFragment;
	private AcquisitionControlActivity	acquisitionControlActivity;
	private volatile int	viewImageAmpMax;
	private volatile int	viewImageChan;
	private volatile int	viewImageMagTime;
//	private int	lastCycleNum_updateDisplay;
//	private int	lastSeam_updateDisplay;
	private volatile boolean	suspendXfrUpdates;

	private float lgPanelWidth_f;
	private float ticksWidth_f;

	private int	numUnchangedSeams;
	private UpdateViewImage	updateViewImageClass;
	private boolean	verticalOrientation;
	private int	lastPlotPointsIndex;
	private float[]	samplePointsArray;
	private int samplePointsArraySizeFloats;
	private Paint	offsetPaint;
	private boolean	firstPassPlot;
	private int plotEraseWidth;
	private int	serverTransmissionTimeout=5;		// maximum time allowed for a server transmission pause, in secs
	private int	serverConnectionTimeout=10;			// maximum time allowed for first server connection, in secs
	private static final int	UPDATE_DISPLAY_RESCHED_PERIOD=100;	// period between scheduled screen updates, in msec
	private int	lastSamplePointsIndex;
	private int	showAbsChan;	
	private int	lastAbsChan;
	private int viewImageBackgroundChan;
	private int viewImageBackgroundAmpMax;
	private int	viewImageBackgroundMagTime;
	private int	remoteNumChannels;
	private int	remoteNumChannelsXfr;
	private int	remoteSampleRate;
	private float	samplePointsWrapY;
	private GestureDetector gestureDetector;
	private ScaleGestureDetector	scaleGestureDetector;
	private boolean[]	channelIsValid;
	private boolean	reSyncToastShown;
	private volatile int	samplePointsChan;
	private int	numFirstConnectionTries;
	private float	onScaleStartingSpanX;
	private boolean	onScaleXDone;
	
	public SingleLeadView(Context context, RemoteAcquisitionFragment raf, AcquisitionControlActivity aca, Bundle inState)
		{
		super(aca.getApplicationContext());
		acquisitionControlActivity = aca;
		remoteAcquisitionFragment = raf;
		
		// initialize all saved state variables
			
		ampMax = 262;
		magTime = 8;
		lastPosition_updateDisplay = 0;

		// restore any saved state
		if (inState != null)
			onRestoreInstanceState(inState);
		
		viewImageBackgroundForOnDraw = null;
		remoteNumChannels = 0;
		samplePointsChan = 0;
		suspendXfrUpdates = false;
		lgPanelWidth_f = 0.f;
		numFirstConnectionTries = 0;
		
		numUnchangedSeams = 0;
		
		samplePointsArraySizeFloats = -1;
		lastPlotPointsIndex = 0;
		firstPassPlot = true;
		lastSamplePointsIndex = -1;
		
		viewImageAmpMax = 0;
		
		SharedPreferences preferences = context.getSharedPreferences("BSChannelViewer", Context.MODE_PRIVATE);
	    String connectionTimeout = preferences.getString("serverConnectionTimeout", "10");
	    serverConnectionTimeout = (int)Integer.valueOf(connectionTimeout);
	    if (serverConnectionTimeout < 10)
	    	serverConnectionTimeout = 10;
	    
	    String transmissionTimeout = preferences.getString("serverTransmissionTimeout", "5");
	    serverTransmissionTimeout = (int)Integer.valueOf(transmissionTimeout);
	    if (serverTransmissionTimeout < 5)
	    	serverTransmissionTimeout = 5;
	    
		verticalOrientation = false;
		if (acquisitionControlActivity.getResources().getConfiguration().orientation ==  Configuration.ORIENTATION_PORTRAIT)
			verticalOrientation = true;

		showAbsChan = acquisitionControlActivity.getChannelToPlot();
		updateViewImageClass = new UpdateViewImage(this, remoteAcquisitionFragment);
		updateViewImageClass.setDaemon(true);
		updateViewImageClass.start();

		scaleGestureDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener()
			{
			@Override
			public boolean onScale(ScaleGestureDetector detector)
	    		{
				boolean result = false;
				
				// test if scale starting 
				if (onScaleStartingSpanX < 0.0f)
					{
					// remember starting spanX
					onScaleStartingSpanX = detector.getCurrentSpanX();
					onScaleXDone = false; 
					result = true;
					}
				else if (onScaleXDone == false)
					{
					// spanX change not yet big enough, i.e. double or half starting spanX
					float currentSpanX = detector.getCurrentSpanX();
					float scaleFactor = currentSpanX/onScaleStartingSpanX;
					if (scaleFactor > 2.0f)
						{
						// spanX now double starting value
						// fingers moving apart, expand time scale
							if (magTime > 1)
								{
								magTime /= 2;
								invalidate();
								onScaleXDone = true;
								result = true;
								}
						}
					else if (scaleFactor < 0.5f)
						{
						// spanX now half starting value
           				// fingers moving together, compress time scale
						magTime *= 2;
						invalidate();
						onScaleXDone = true;
						result = true;
						}
					}// onScaleDone == false
				
				return result;
	    		}
			});

		gestureDetector = new GestureDetector(context, new SimpleOnGestureListener()
			{			
			// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true
			
			@Override
			public boolean onDown(MotionEvent evt)
				{
				// NOTE: for some reason the overrides don't work unless the 'onDown' is present and returns true
				
				return true;
				}

			@Override
			public boolean onDoubleTap(MotionEvent e)
				{
				// double tap cycles through possible amplitude scales
				boolean result = false;

				int newAmpMax = ampMax;
				
				if (ampMax == 262)
					newAmpMax = 100;
				else if (ampMax == 100)
					newAmpMax = 50;
				else if (ampMax == 50)
					newAmpMax = 20;
				else if (ampMax == 20)
					newAmpMax = 262;

				if (newAmpMax != ampMax)
					{
					setMaxAmplitude(newAmpMax);
					
					result = true;
					}
				
				return result;
				}

			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY)
				{
				boolean result = false;
				
				if ((e1 == null) || (e2 == null))
					return false;

				// fling only when doing single touch
				if (e1.getPointerCount() > 1)
					return false;
				if (e2.getPointerCount() > 1)
					return false;
			
				if (Math.abs(velocityX) > Math.abs(velocityY))
					{
					// finger moving mainly in x direction, left or right
					// try to avoid false fling
					if ((Math.abs(velocityX) > 500.f) && (Math.abs(e1.getX()-e2.getX()) > 50.f))
						{
						// fast fling
						if (e1.getX() > e2.getX())
							{
							// finger moving left, increase channel number
							int nextChan = showAbsChan + 1;
							if (nextChan >= remoteNumChannels)
								nextChan = 2;
							acquisitionControlActivity.setChannelToPlot(nextChan);
							result = true;
							}
						else
               				{
							// finger moving right, decrease channel number
							int nextChan = showAbsChan - 1;
							if (nextChan < 2)
								nextChan = remoteNumChannels-1;
							acquisitionControlActivity.setChannelToPlot(nextChan);
							result = true;
               				}
						}// fast x fling
					}// x fling
				else						
					{
					// finger moving mainly in y direction, up or down
					// try to avoid false fling
					if ((Math.abs(velocityY) > 500.f) && (Math.abs(e1.getY()-e2.getY()) > 50.f))
						{
						if (e1.getY() > e2.getY())
							{
							// finger moving up, unsuspend xfr updates
							if (suspendXfrUpdates == true)
								{
								acquisitionControlActivity.resumeXfrUpdates();
								result = true;
								}
							}
						else
							{// finger moving down, suspend xfr updates
							if (suspendXfrUpdates == false)
								{
								acquisitionControlActivity.suspendXfrUpdates();							
								result = true;
								}
							}
						}// fast y fling
					}// y fling

				return result;
				}			
			});// SimpleOnGestureListener
		
		setOnTouchListener(new OnTouchListener()
			{
			@Override
			public boolean onTouch(View v, MotionEvent evt)
				{
				// if not within a scale gesture, initialize scale variables
				if (!scaleGestureDetector.isInProgress())
					{
					onScaleStartingSpanX = -1.0f;
					onScaleXDone = false;
					}

				// Let the ScaleGestureDetector inspect all events.
			    boolean result = scaleGestureDetector.onTouchEvent(evt);
			    
				// monitor only when doing single touch
				if (evt.getPointerCount() > 1)
					return result;
				
				return gestureDetector.onTouchEvent(evt);
				}// onTouch
			});// OnTouchListener
		}// SingleLeadView constructor
	
	private void updateDisplay()
		{
		/*
		 * driven by either postDelayed run requests scheduled below or onVisibilitycChanged calls;
		 * tracks "ring buffer" position by getSampleBufferSeam calls
		*/

		if (updateViewImageClass.stopRequested == true)
			return;

		// monitor sample buffer seam changes
		long position = remoteAcquisitionFragment.getSampleBufferSeam();

//		int cycleNum = (int)(position>>32);
//		int seam = (int)(position&0xffffffff);

		if (position < 0)
			{
			// seam is -2 or -3 when trying for first connection to sample server
			// watch for first connection timeout
			if ((position < -1) && (numFirstConnectionTries++ > (serverConnectionTimeout*1000)/UPDATE_DISPLAY_RESCHED_PERIOD))
				{
				Toast toast = Toast.makeText(acquisitionControlActivity.getApplicationContext(),
					"Unable to connect to TCP host "+remoteAcquisitionFragment.getHost()+
					" port "+remoteAcquisitionFragment.getPort()+
					" within "+((numFirstConnectionTries*UPDATE_DISPLAY_RESCHED_PERIOD/1000))+" seconds!",
	    			Toast.LENGTH_LONG);
				toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
				toast.show();				

				acquisitionControlActivity.cancelAcquisition();
				if (updateViewImageClass != null)
					updateViewImageClass.requestStop();
	
				return;
				}

			// don't show re-sync toast if first connection or just switching xfr leads
			// (position is -2 or -3 during first connection)
			else if ((position == -1) && ((lastAbsChan-2)/32 == (showAbsChan-2)/32) && (updateViewImageClass.stopRequested == false) &&
				(acquisitionControlActivity.getAcquisitionCancelled() == false) && (reSyncToastShown == false))
				{
				Toast toast = Toast.makeText(this.getContext(), "Re-Syncing", Toast.LENGTH_LONG);
				toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
				toast.show();
				reSyncToastShown = true;
				}
			else
				lastPosition_updateDisplay = position;
			}// position < 0
		
		else if (position == lastPosition_updateDisplay)
			{
			// count unchanged seams
						
			if (((numUnchangedSeams++ >= (serverTransmissionTimeout*1000)/UPDATE_DISPLAY_RESCHED_PERIOD) &&
				remoteAcquisitionFragment.isConnected() && ((position != 0) || (lastPosition_updateDisplay != 0))) ||
				(numUnchangedSeams >= (2*serverTransmissionTimeout*1000)/UPDATE_DISPLAY_RESCHED_PERIOD))
				{
				if ((remoteAcquisitionFragment.isConnected())  && ((position != 0) || (lastPosition_updateDisplay != 0)))
					{
					Toast toast = Toast.makeText(acquisitionControlActivity.getApplicationContext(),
						"No TCP input from server during the last "+
						((numUnchangedSeams*UPDATE_DISPLAY_RESCHED_PERIOD/1000))+" seconds!",
						Toast.LENGTH_LONG);
					toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
					toast.show();
					}

				acquisitionControlActivity.cancelAcquisition();
				if (updateViewImageClass != null)
					updateViewImageClass.requestStop();
				return;
				}
			}// position == lastPosition_updateDisplay
		else
			{
			if ((lastPosition_updateDisplay < -1) && (position >= 0))
				{
				Toast toast = Toast.makeText(acquisitionControlActivity.getApplicationContext(),
						"Connected", Toast.LENGTH_LONG);
				toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
				toast.show();
				}

			lastPosition_updateDisplay = position;
			numUnchangedSeams = 0;
			reSyncToastShown = false;

			// samples are now being read so get remote values

			if (remoteNumChannels == 0)
				remoteNumChannels = remoteAcquisitionFragment.getRemoteNumChannels();
			if (remoteNumChannelsXfr == 0)
				remoteNumChannelsXfr = remoteAcquisitionFragment.getRemoteNumChannelsXfr();
			if (remoteSampleRate == 0)
				remoteSampleRate = remoteAcquisitionFragment.getRemoteSampleRate();
			}

		if (isShown() && (updateViewImageClass.stopRequested == false))
			{
			int currentSamplePointsIndex = updateViewImageClass.getCurrentSamplePointsIndex();

			if ((currentSamplePointsIndex != lastSamplePointsIndex) && (viewImageBackgroundForOnDraw != null) && (reSyncToastShown == false))
				invalidate();
			lastSamplePointsIndex = currentSamplePointsIndex;
			
			// re-schedule updateDisplay call,
			// which will run in this thread,
			// which was first called from onVisibilityChanged,
			// which seems to be running on the ui thread
			
			postDelayed(new Runnable()
				{
				@Override
				public void run()
					{
					updateDisplay();
					}
				}, UPDATE_DISPLAY_RESCHED_PERIOD);
			}// isShown == true
		else
			{
			numUnchangedSeams = 0;
			}
		}// updateDisplay()

	@Override
	protected void onVisibilityChanged(View v, int visibility)
		{
		if (visibility == GONE)
			numUnchangedSeams = 0;
		else
			{
			numUnchangedSeams = 0;
			
			updateDisplay();
			}
		}
	
	@Override
	protected void onDraw(Canvas canvas)
		{
		// get view dimensions
		int height = getHeight();

		if (height > 0)
			{
			if (((viewImageBackground == null) || (viewImageBackgroundAmpMax != viewImageAmpMax) || (viewImageBackgroundMagTime != viewImageMagTime) ||
				((viewImageBackgroundChan-2)/32 != (viewImageChan-2)/32)) && (viewImageBackgroundForOnDraw != null))
				{
				if (viewImageBackground != null)
					{
					viewImageBackground.recycle();
					viewImageBackground = null;
					}
					
				synchronized(viewImageBackgroundForOnDraw)
					{
					viewImageBackground = viewImageBackgroundForOnDraw.copy(viewImageBackgroundForOnDraw.getConfig(),  false);
				
					viewImageBackgroundChan = viewImageChan;
					viewImageBackgroundAmpMax = viewImageAmpMax;
					viewImageBackgroundMagTime = viewImageMagTime;
					}
				offsetPaint = null;		// new background so new paint (draw colour)
				}

			// draw background
			if (viewImageBackground != null)
				{
				canvas.drawBitmap(viewImageBackground, 0.f, 0.f, null);

				if ((samplePointsChan == showAbsChan) && (viewImageBackgroundAmpMax == ampMax))
					{
					if (samplePointsArraySizeFloats == -1)
						{
						samplePointsArray = updateViewImageClass.getSamplePointsArray();
						if (samplePointsArray != null)
							{
							samplePointsArraySizeFloats = updateViewImageClass.getSamplePointsArraySizeFloats();
							plotEraseWidth = (int)(lgPanelWidth_f*0.05)*4;
							}
						}
	
					if (offsetPaint == null)
						{
						offsetPaint = new Paint();
						offsetPaint.setStyle(Paint.Style.STROKE);
						offsetPaint.setAntiAlias(true);			// THIS IS VERY IMPORTANT WHEN DRAWING LINES

						final float densityScale = getResources().getDisplayMetrics().density;
						offsetPaint.setStrokeWidth((densityScale>1.1f)?0.0f:3.0f);

						offsetPaint.setTextSize((densityScale>1.1f)?12.f:18.f);
						}
						
					updateViewImageClass.updateTitle(canvas, offsetPaint);
						
					offsetPaint.setColor(Color.BLACK);
	
					if (samplePointsArray != null)
						{
						int currentSamplePointsIndex = updateViewImageClass.getCurrentSamplePointsIndex();
						int numNewPlotPoints = currentSamplePointsIndex - lastPlotPointsIndex;
						if (numNewPlotPoints < 0)
							numNewPlotPoints += samplePointsArraySizeFloats;

						// plot new lines
		
						if (currentSamplePointsIndex < lastPlotPointsIndex)
							{
							firstPassPlot = false;
							}

						if (viewImageBackground != null)
							{
							// make sure samples have arrived
							if (!firstPassPlot || (currentSamplePointsIndex > 0))
								{
								// check if erased section is split at the right margin
						
								if (currentSamplePointsIndex+plotEraseWidth < samplePointsArraySizeFloats)
									{
									// erased area not split at right margin
									// plot from left margin to erase point start
									canvas.drawLines(samplePointsArray, 0, currentSamplePointsIndex, offsetPaint);
							
									if (!firstPassPlot)
										{// plot from erase point end to right margin
										int startAt = currentSamplePointsIndex+plotEraseWidth;
										canvas.drawLines(samplePointsArray, startAt, samplePointsArraySizeFloats-startAt, offsetPaint);
										}
									}
								else
									{
									// erased area split at the right margin
									// plot in center from erase point end to erase point start
									canvas.drawLines(samplePointsArray, currentSamplePointsIndex+plotEraseWidth-samplePointsArraySizeFloats,
										samplePointsArraySizeFloats-plotEraseWidth, offsetPaint);
									}
					
								}// (!firstPassPlot || (currentSamplePointsIndex > 0))

							lastPlotPointsIndex = currentSamplePointsIndex;
							}  // viewImageBackground != null

						} // samplePointsArray != null
					} // (samplePointsChan == showAbsChan) && (viewImageBackgroundAmpMax == ampMax)
				} // viewImageBackground != null
			}  // height > 0

		return;
		}	// onDraw()
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
		{
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = MeasureSpec.getSize(widthMeasureSpec);

		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int heightSize = MeasureSpec.getSize(heightMeasureSpec);

		int chosenWidth = chooseDimension(widthMode, widthSize);
		int chosenHeight = chooseDimension(heightMode, heightSize);

		setMeasuredDimension(chosenWidth, chosenHeight);
		}

	private int chooseDimension(int mode, int size)
		{
		if (mode == MeasureSpec.AT_MOST || mode == MeasureSpec.EXACTLY)
			return size;
		else // (mode == MeasureSpec.UNSPECIFIED)
			return getPreferredSize();
		}

	// in case there is no size specified
	private int getPreferredSize()
		{
		return 300;
		}

	public void setChannelToPlot(int chanOffset)
	// chanOffset counts from 0
		{
		if (chanOffset != showAbsChan)
			{
			showAbsChan = chanOffset;
			lastPlotPointsIndex = 0;
			}
		}
	
	public void setMaxAmplitude(int newAmpMax)
		{
		if (newAmpMax != ampMax)
			{
			if (viewImageBackgroundForOnDraw != null)
				synchronized(viewImageBackgroundForOnDraw)
					{
					viewImageBackgroundForOnDraw.recycle();
					viewImageBackgroundForOnDraw = null;
					}

			ampMax = newAmpMax;
			}
		}

	public void requestStop()
		{
		if (updateViewImageClass != null)
			updateViewImageClass.requestStop();
		}

	public void onSaveInstanceState(Bundle outState)
		{
		outState.putInt("slv_ampMax",  ampMax);
		outState.putInt("slv_magTime",  magTime);
		outState.putLong("slv_lastPosition_updateDisplay",  lastPosition_updateDisplay);
	
		if (updateViewImageClass != null)
			updateViewImageClass.onSaveInstanceState(outState);
	
		if (viewImageBackgroundForOnDraw != null)
			{
			viewImageBackgroundForOnDraw.recycle();
			viewImageBackgroundForOnDraw = null;
			}
	
		if (viewImageBackground != null)
			{
			viewImageBackground.recycle();
			viewImageBackground = null;
			}
	
		}

	public void onRestoreInstanceState(Bundle inState)
		{
		if (inState != null)
			{
			Set<String> keys = inState.keySet();

			if (keys.contains("slv_ampMax"))
				ampMax = inState.getInt("slv_ampMax");

			if (keys.contains("slv_magTime"))
				magTime = inState.getInt("slv_magTime");

			if (keys.contains("slv_lastPosition_updateDisplay"))
				lastPosition_updateDisplay = inState.getLong("slv_lastPosition_updateDisplay");
			
			if (updateViewImageClass != null)
				updateViewImageClass.onRestoreInstanceState(inState);
			}
		}

	public void suspendXfrUpdates()
		{
		suspendXfrUpdates = true;
		}

	public void resumeXfrUpdates()
		{
		suspendXfrUpdates = false;
		if (updateViewImageClass != null)
			updateViewImageClass.resumeXfrUpdates();
		}

	private class UpdateViewImage extends Thread implements IAcquisitionSamplesWaiter
		{
	
		// variables that must be saved/restored when orientation changes 
	
		int lastCycleNum;
		int	lastSeam;

		// other variables
	
		int currentCycleNum;
		int currentSeam;
		int	lastTupleIndex;
		RemoteAcquisitionFragment	remoteAcquisitionFragment;
		final SingleLeadView	slView;
		float	lgPanelTopMargin_f;
		float	lgPanelLeftMargin_f;
		float	lgPanelRightMargin_f;
		float	lgPanelHeight_f;
		float[]	samplePoints;
		int	samplePointsIndex;
		float	ampMax_f;
		float	lgUpperPanelZeroLine_f;
		float	pixelsPerLGCount_f;
		private int[]	sampleBuffer;
		private int	sampleBufferSizeInts;
		private volatile int	currentSamplePointsIndex;
		private boolean	stopRequested;
		private Handler	newSamplesAvailableHandler;
		private float	lgLabelAt;
		private float	xfrRateAt;
		private int	rawSampleStride;
		private float	rawSampleStrideTruncError_f;
		private float	accumulatedRawSampleStrideTruncError_f;

	public UpdateViewImage(SingleLeadView slv, RemoteAcquisitionFragment raf)
		{
		/*
		 * tracks "ring buffer" pointer by newAcquisitionSamples notification callbacks
		 */
		slView = slv;
		remoteAcquisitionFragment = raf;
		lastSeam = -1;
		currentCycleNum = 0;
		currentSeam = -1;
		lastTupleIndex = -1;
		sampleBufferSizeInts = -1;
		samplePointsIndex = 0;
		currentSamplePointsIndex = -1;
		stopRequested = false;
		lastAbsChan = -1;
		samplePoints = null;
		}

	@Override
	public void run()
		{	
		Looper.prepare();

		newSamplesAvailableHandler = new Handler()
    		{
			@Override
			public void handleMessage(Message msg)
        		{
				super.handleMessage(msg);
				
				if (stopRequested)
					{
					if (samplePoints != null)
						samplePoints = null;

					if (viewImageBackgroundForOnDraw != null)
						{
						viewImageBackgroundForOnDraw.recycle();
						viewImageBackgroundForOnDraw = null;
						}
					if (viewImageBackground != null)
						{
						viewImageBackground.recycle();
						viewImageBackground = null;
						}
					
					if (newSamplesAvailableHandler != null)
						newSamplesAvailableHandler.removeCallbacksAndMessages(null);
					newSamplesAvailableHandler = null;
					
		    		Looper.myLooper().quit();
					}
				
				if (msg.arg2 >= 0)
					{
					currentSeam = msg.arg2;
					currentCycleNum = msg.arg1;
					
					if ((currentCycleNum > lastCycleNum+1) ||
							((currentCycleNum == lastCycleNum+1) && (currentSeam >= lastSeam)))
							{
							// application can't keep up to sample stream rate
							if (updateViewImageClass != null)
								updateViewImageClass.requestStop();
							acquisitionControlActivity.cancelAcquisition();

							Toast toast = Toast.makeText(acquisitionControlActivity.getApplicationContext(),
								"Application lapped by input stream - try requesting fewer channels",
				    			Toast.LENGTH_LONG);
							toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
							toast.show();				
							return;
							}
					
					if ((remoteNumChannels > 0) && (lastSeam >= 0) && (suspendXfrUpdates == false))
						appendNewSamples(lastSeam, currentSeam);

					lastCycleNum = currentCycleNum;
					lastSeam = currentSeam;
					}
        		} // handle message
    		}; // handler()
		
    	if (stopRequested)
    		{
			if (newSamplesAvailableHandler != null)
				newSamplesAvailableHandler.removeCallbacksAndMessages(null);
			newSamplesAvailableHandler = null;

			Looper.myLooper().quit();
    		}
		
    	remoteAcquisitionFragment.addAcquisitionSamplesListener(UpdateViewImage.this);

    	Looper.loop();
		} // run

	public void requestStop()
		{
		stopRequested = true;
		remoteAcquisitionFragment.removeAcquisitionSamplesListener(UpdateViewImage.this);
		}

	private void appendNewSamples(int lastSeam, int currentSeam)
		{
		// driven by new newAcquisitionSamples notification callbacks from remoteAcquisitionFragment
		
		// did channel or scaling change since static background bitmap 'viewImage' was made
		if ((showAbsChan != samplePointsChan) || (ampMax != viewImageAmpMax) || (magTime != viewImageMagTime))
			{
			// initialize variables that change when the above values change
			
			samplePointsIndex = 0;							// start plot at left margin
			currentSamplePointsIndex = samplePointsIndex;
			
			samplePointsChan = showAbsChan;
			firstPassPlot = true;
			lastPlotPointsIndex = 0;
			if (lastTupleIndex < 0)
				lastTupleIndex = lastSeam - remoteNumChannels;	// only on first set of samples

			// if lead group changed since background bitmap was made, create a new valid channel array 
			if ((channelIsValid == null) || ((showAbsChan-2)/32 != (viewImageChan-2)/32))
				{
				int[] channelXfrVector = remoteAcquisitionFragment.getChannelXfrVector();		// channels being transferred
				remoteNumChannelsXfr = remoteAcquisitionFragment.getRemoteNumChannelsXfr();		// #channels being transferred
		
				if (channelXfrVector != null)
					{
					channelIsValid = new boolean[remoteNumChannels];

					for (int i=0; i<remoteNumChannels; i++)
						channelIsValid[i] = false;
			
					for (int i=0; i<remoteNumChannelsXfr; i++)
						{
						channelIsValid[channelXfrVector[i]] = true;
						}
					}
				}// lead group change
		
			// check if a new viewImage bitmap is needed, i.e. lead group or scale changed 
			if ((ampMax != viewImageAmpMax) ||
					((showAbsChan-2)/32 != (viewImageChan-2)/32) || (magTime != viewImageMagTime))
				{
				// destroy any previous viewImage bitmap
				if (viewImageBackgroundForOnDraw != null)
					synchronized(viewImageBackgroundForOnDraw)
						{
						viewImageBackgroundForOnDraw.recycle();
						viewImageBackgroundForOnDraw = null;
						}
				}
			}

		// is a new viewImage required
		
		if ((viewImageBackgroundForOnDraw == null) && (slView.getHeight() == 0))
			return;		// wait until view size is available
		
		if ((viewImageBackgroundForOnDraw == null) ||
			((viewImageBackgroundForOnDraw != null) && (slView.getHeight() != viewImageBackgroundForOnDraw.getHeight())))
			{
			// try to create new bitmap
			Bitmap viewImageBackgroundThread = createViewImage(slView.getHeight(), slView.getWidth());

			if ((viewImageBackgroundThread == null) || (lgPanelWidth_f < 1.0f))
				return;				// sizes probably not yet available

			// make newly created viewImage (viewImageBackgroundThread) available for onDraw call
			if (viewImageBackgroundForOnDraw != null)
				synchronized(viewImageBackgroundForOnDraw)
					{
					viewImageBackgroundForOnDraw.recycle();
					viewImageBackgroundForOnDraw = viewImageBackgroundThread.copy(viewImageBackgroundThread.getConfig(),  false);

					viewImageAmpMax = ampMax;
					viewImageChan = showAbsChan;
					viewImageMagTime = magTime;
					}
			else
				{	
				viewImageAmpMax = ampMax;
				viewImageChan = showAbsChan;
				viewImageMagTime = magTime;
				
				viewImageBackgroundForOnDraw = viewImageBackgroundThread.copy(viewImageBackgroundThread.getConfig(),  false);
				}
			
			viewImageBackgroundThread.recycle();
			viewImageBackgroundThread = null;
			}
		
		if (sampleBufferSizeInts == -1)
			{
			sampleBuffer = remoteAcquisitionFragment.getSampleBuffer();
			sampleBufferSizeInts = remoteAcquisitionFragment.getSampleBufferSizeInts();
			}

		// determine #new samples available
		int numNewSamplesAvail = currentSeam - lastTupleIndex;
		if (numNewSamplesAvail < 0)
			numNewSamplesAvail += sampleBufferSizeInts;
		
		// as a multiple of channel set size
		numNewSamplesAvail = (numNewSamplesAvail/remoteNumChannels)*remoteNumChannels;
	
		// is there enough to do a stride
		if (numNewSamplesAvail > (rawSampleStride*remoteNumChannels + remoteNumChannels))
			{
			// step one stride
			int nextTupleIndex = lastTupleIndex + rawSampleStride*remoteNumChannels;

			// accumulate stride truncation error
			accumulatedRawSampleStrideTruncError_f += rawSampleStrideTruncError_f;

			// determine number of new samples
			int numNewSamples = currentSeam - nextTupleIndex;
			if (numNewSamples < 0)
				numNewSamples += sampleBufferSizeInts;
			
			// as a multiple of channel set size
			numNewSamples = (numNewSamples/remoteNumChannels)*remoteNumChannels;
		
			// make sure scaled samples array is allocated
			if ((samplePoints == null) || (samplePoints.length == 0))
				{	
				samplePoints = new float[(int)lgPanelWidth_f*4];
				samplePointsIndex = 0;
			
				samplePointsWrapY = 0.f;
				}
			
			// step through sampleBuffer by rawSampleStride*remoteNumChannels scaling
			// raw samples into the samplePoints array
			// note:
			// 1. each entry in samplePoints defines a line and so occupies 4 entries
			// xStart, yStart, xEnd, yEnd thus
			// 2. the size of samplePoints is 4*the width of the graph section of the screen 
			
			for (int i=0; (i+remoteNumChannels)<numNewSamples;
				i+=(rawSampleStride*remoteNumChannels),
				nextTupleIndex+=(rawSampleStride*remoteNumChannels),
				accumulatedRawSampleStrideTruncError_f+=rawSampleStrideTruncError_f)
				{
				// step an additional channel set when the accumulated truncation error exceeds 1
				if (accumulatedRawSampleStrideTruncError_f > 1.0f)
					{
					i += remoteNumChannels;				// step sample counter
					if ((i+remoteNumChannels) >= numNewSamples)
						break;							// exceeds number new samples

					nextTupleIndex += remoteNumChannels;			// step actual buffer index 
					accumulatedRawSampleStrideTruncError_f -= 1.0f;		// adjust accumulated truncation error
					}
			
				// check for wraparound
				if (nextTupleIndex >= sampleBufferSizeInts)
					nextTupleIndex -= sampleBufferSizeInts;

				// get the raw samples value
				int samp = 0;
				if (!channelIsValid[showAbsChan])
					samp = 0xffffff00;				// use this for samples that are not present (shouldn't happen)
				else if (nextTupleIndex+showAbsChan < sampleBufferSizeInts)
					samp = sampleBuffer[nextTupleIndex+showAbsChan];
				else
					samp = sampleBuffer[nextTupleIndex+showAbsChan-sampleBufferSizeInts];
			
				// scale it
				float sample_f = (float)samp/31.25f/1000.f;		// mvolts
				if (sample_f > ampMax_f)
					sample_f = ampMax_f;
				else if (sample_f < -ampMax_f)
					sample_f = -ampMax_f;
				
				// position it on the y axis
				// on the screen 0 is at top so (zeroLine-sample) puts +ve samples above
				// the zeroLine and -ve samples below 
				float amp_f = lgUpperPanelZeroLine_f - sample_f*pixelsPerLGCount_f;

				float x = lgPanelLeftMargin_f + (float)(samplePointsIndex/4);

				// store the 4 line coordinates, xStart, Ystart, xEnd, yEnd
				if (samplePointsIndex == 0)
					{
					samplePoints[0] = lgPanelLeftMargin_f;
					samplePoints[1] = (firstPassPlot == true)?amp_f:samplePointsWrapY;
					samplePoints[2] = x;
					samplePoints[3] = amp_f;
					samplePointsIndex = 4;
					}
				else
					{
					int firstOf4 = samplePointsIndex;
					samplePoints[samplePointsIndex++] = samplePoints[firstOf4-2];	// start at end of last line
					samplePoints[samplePointsIndex++] = samplePoints[firstOf4-1];			
					samplePoints[samplePointsIndex++] = x;
					samplePoints[samplePointsIndex++] = amp_f;
					}

				// check for wraparound
				if (samplePointsIndex >= samplePoints.length)
					{
					samplePointsWrapY = samplePoints[samplePointsIndex-1];	// same Y at right margin for use at left margin
					samplePointsIndex -= samplePoints.length;
					}

				// remember index of last raw data tuple used			
				lastTupleIndex = nextTupleIndex;			
				} // add new points

			// remember index of last screen line used
			currentSamplePointsIndex = samplePointsIndex;
	
			// remember channel being plotted
			lastAbsChan = showAbsChan;
			}// there are enough raw samples to do a stride
		
		}// appendNewSamples()

	private int getCurrentSamplePointsIndex()
		{
		return currentSamplePointsIndex;
		}

	private int getSamplePointsArraySizeFloats()
		{
		return (samplePoints==null)?0:samplePoints.length;
		}

	private float[] getSamplePointsArray()
		{
		return samplePoints;
		}

	private Bitmap createViewImage(int vHeight, int vWidth)
		{
		// create a background bitmap for the plot that's good until
		// there's a scale (ampMax, maxTime), channel group (showAbsChan/32) or
		// screen size change
		
		Bitmap vImage = Bitmap.createBitmap(vWidth, vHeight, Bitmap.Config.ARGB_8888);

		Canvas viCanvas = new Canvas(vImage);

		float width_f = (float)vWidth;
		float height_f = (float)vHeight;
	
		lgPanelWidth_f = width_f * 0.92f;
		ticksWidth_f = width_f * 0.06f;

		float leftMargin_f = (width_f - ticksWidth_f - lgPanelWidth_f)/2.f;

		lgPanelRightMargin_f = width_f - leftMargin_f;
		lgPanelLeftMargin_f = lgPanelRightMargin_f - lgPanelWidth_f;
		
		lgPanelHeight_f = height_f * 0.42f;
		lgPanelHeight_f = height_f * 0.84f;
	
		lgPanelTopMargin_f = height_f * 0.05f;

		float rawSampleStride_f = ((float)remoteSampleRate/lgPanelWidth_f)*(float)(magTime);
		rawSampleStride = (int)rawSampleStride_f;
		rawSampleStrideTruncError_f = rawSampleStride_f - (float)rawSampleStride;
		accumulatedRawSampleStrideTruncError_f = 0.f;
	
		ampMax_f = (float)ampMax;
		pixelsPerLGCount_f = lgPanelHeight_f/2.0f/ampMax_f;
	
		int numHorizontalTicks = 7;
		int tickInc = 50;

		if (ampMax == 20)
			{
			numHorizontalTicks = 5;
			tickInc = 5;
			}
		else if (ampMax == 50)
			{
			numHorizontalTicks = 6;
			tickInc = 10;
			}
		else if (ampMax == 100)
			{
			numHorizontalTicks = 6;
			tickInc = 20;
			}
	
		Paint offsetPaint = new Paint();
		offsetPaint.setColor(Color.BLACK);

		// flood fill the whole background
	
		int frameColor = Color.rgb(0x95, 0x8d, 0xb6);
		viCanvas.drawColor(frameColor);

		RectF lgPanelRect = new RectF(lgPanelLeftMargin_f, lgPanelTopMargin_f, lgPanelLeftMargin_f+lgPanelWidth_f, lgPanelTopMargin_f+lgPanelHeight_f); 

		// shade fill the graph panel
	
		int innerColor = Color.rgb(0xcc, 0xcc, 0xff);
		offsetPaint.setShader(new LinearGradient(lgPanelRect.left, lgPanelRect.top, lgPanelRect.right, lgPanelRect.bottom,
			innerColor, Color.WHITE, Shader.TileMode.MIRROR));

		viCanvas.drawRect(lgPanelRect, offsetPaint);

		offsetPaint.setShader(null);

		float pixelsPerTick_f = pixelsPerLGCount_f * (float)tickInc;
	
		offsetPaint.setColor(Color.BLACK);
		lgUpperPanelZeroLine_f = lgPanelTopMargin_f + lgPanelHeight_f/2.0f;
	
		int gridColor = Color.rgb(0xc1, 0xc1, 0xc1);
		for (int i=0; i<numHorizontalTicks; i++)
			{
			float y = (float)i*pixelsPerTick_f;
			if (i == 6)
				y = lgPanelHeight_f/2.f;
		
			// draw horizontal tick marks, above and below the zero line
		
			offsetPaint.setColor(Color.BLACK);
			viCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgUpperPanelZeroLine_f-y, lgPanelLeftMargin_f, lgUpperPanelZeroLine_f-y, offsetPaint);
			viCanvas.drawLine(lgPanelLeftMargin_f-5.f, lgUpperPanelZeroLine_f+y, lgPanelLeftMargin_f, lgUpperPanelZeroLine_f+y, offsetPaint);
		
			// draw horizontal grid lines
		
			if (i != (numHorizontalTicks-1))
				{
				offsetPaint.setColor(gridColor);
				viCanvas.drawLine(lgPanelLeftMargin_f, lgUpperPanelZeroLine_f-y, lgPanelLeftMargin_f+lgPanelWidth_f, lgUpperPanelZeroLine_f-y, offsetPaint);
				viCanvas.drawLine(lgPanelLeftMargin_f, lgUpperPanelZeroLine_f+y, lgPanelLeftMargin_f+lgPanelWidth_f, lgUpperPanelZeroLine_f+y, offsetPaint);
				}

			// label horizontal tick marks
		
			offsetPaint.setColor(Color.BLACK);
			final float densityScale = getResources().getDisplayMetrics().density;
			offsetPaint.setTextSize((densityScale>1.1f)?12.f:18.f);
			if ((numHorizontalTicks < 7) || (i != 5))
				{
				String tickLabel = String.valueOf((i!=6)?(i*tickInc):ampMax);
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				viCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgUpperPanelZeroLine_f-y+tickLabelRect.height()/2.0f, offsetPaint);

				tickLabel = String.valueOf((i!=6)?(-i*tickInc):-ampMax);
				tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				viCanvas.drawText(tickLabel, lgPanelLeftMargin_f-6.f-tickLabelRect.width(), lgUpperPanelZeroLine_f+y+tickLabelRect.height()/2.0f, offsetPaint);
				}			
			}// draw and label horizontal ticks and grid lines

		// draw vertical grid lines, above and below the zero line
		// extend every 4th at bottom to have as a tick mark

		int labelInc = 250;
		if (verticalOrientation == true) 
			labelInc = 100;
	
		for (int i=0; i<=1000; i+=25)
			{
			float x = ((float)i/1000.f)*lgPanelWidth_f;
			if ((i == 0) || (i == 1000))
				{
				offsetPaint.setColor(Color.BLACK);
				viCanvas.drawLine(lgPanelLeftMargin_f+x, lgPanelTopMargin_f+lgPanelHeight_f, lgPanelLeftMargin_f+x, lgPanelTopMargin_f+lgPanelHeight_f+5.f, offsetPaint);
				}
			else
				{
				offsetPaint.setColor(gridColor);
				viCanvas.drawLine(lgPanelLeftMargin_f+x, lgPanelTopMargin_f, lgPanelLeftMargin_f+x, lgPanelTopMargin_f+lgPanelHeight_f, offsetPaint);

				if ((i%50) == 0)
					{
					offsetPaint.setColor(Color.BLACK);
					viCanvas.drawLine(lgPanelLeftMargin_f+x, lgPanelTopMargin_f+lgPanelHeight_f, lgPanelLeftMargin_f+x, lgPanelTopMargin_f+lgPanelHeight_f+5.f, offsetPaint);
					}
				}

			// label vertical tick marks, below the panel

			if ((i%labelInc) == 0)
				{
				String tickLabel = String.valueOf(i*magTime);
				Rect tickLabelRect = new Rect(0, 0, 1, 1);
				offsetPaint.getTextBounds(tickLabel, 0, tickLabel.length(), tickLabelRect);
				offsetPaint.setColor(Color.BLACK);
				viCanvas.drawText(tickLabel, lgPanelLeftMargin_f+x-tickLabelRect.width()/2.f,
						(lgPanelTopMargin_f+lgPanelHeight_f+height_f)/2.f+tickLabelRect.height()/2.f, offsetPaint);
				}
			}
		
		float prevTextSize = offsetPaint.getTextSize();
		
		int lgOffset = (showAbsChan-2)/32;
		int chanOffset = showAbsChan-2 - lgOffset*32;
		String lgLabel = "Chan"+(showAbsChan+1);
		if ((remoteNumChannels-2)/32 != lgOffset)
			lgLabel = "ABCDEFGH".substring(lgOffset, lgOffset+1) + (chanOffset+1);
		else if ((chanOffset >= 0) && (chanOffset < 8))
			lgLabel = "Ex" + (chanOffset+1);
		else if ((chanOffset >= 8) && (chanOffset < 15))
			lgLabel = "Sn" + (chanOffset-8+1);
		else
			lgLabel = "Z" + (chanOffset-15+1);
		
		Rect lgLabelRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(lgLabel, 0, lgLabel.length(), lgLabelRect);
		offsetPaint.setStrokeWidth(0.0f);
		
		// show remote info in the upper left corner

		boolean savedAntiAlias = offsetPaint.isAntiAlias();
		Typeface savedTypeface = offsetPaint.getTypeface();
		float savedTextSize = offsetPaint.getTextSize();

		offsetPaint.setAntiAlias(true);
		offsetPaint.setTypeface(Typeface.MONOSPACE);
		offsetPaint.setTextSize(offsetPaint.getTextSize()*0.8f);
		
		String remoteInfo = "Remote: "+remoteNumChannels+" Chan @ ~"+remoteSampleRate+"Hz";
		Rect remoteRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(remoteInfo, 0, remoteInfo.length(), remoteRect);

		// show transfer info in the upper right corner
		
		int firstXfr = 0;
		int lastXfr = 0;
		for (int ch=2; ch<remoteNumChannels; ch++)
			if (firstXfr == 0)
				{
				if (channelIsValid[ch] == true)
					firstXfr = ch;
				}
			else if (channelIsValid[ch] == true)
				lastXfr = ch;
		
		int firstLG = (firstXfr-2)/32;
		int lastLG = (lastXfr-2)/32;
		String xfrInfo;
		if ((lastLG == firstLG) && ((lastLG+1)*32 < remoteNumChannels))
			// one group
			xfrInfo = "Xfr "+remoteNumChannelsXfr+": S&S,32"+"ABCDEFGH".substring(firstLG, firstLG+1);
		
		else if (remoteNumChannelsXfr > 32)
			{// all channels 
			if (verticalOrientation == true)
				{
				if (firstLG != lastLG)
					xfrInfo = "Xfr all: S&S,"+"ABCDEFGH".substring(firstLG, firstLG+1) + "1-"+"ABCDEFGH".substring(lastLG-1, lastLG) + "32,"+
						"8Ex,7Sn,"+(((remoteNumChannels-2)%32)-15+"O");
				else
					xfrInfo = "Xfr all: S&S,32"+"ABCDEFGH".substring(firstLG, firstLG+1)+ 
						"8Ex,7Sn,"+(((remoteNumChannels-2)%32)-15+"O");
				}
			else
				xfrInfo = "Xfr all "+remoteNumChannels;
			}

		else
			// just the extra channels at end
			if (verticalOrientation == true)
				xfrInfo = "Xfr "+remoteNumChannelsXfr+": S&S,"+"8Ex,7Sn,"+(((remoteNumChannels-2)%32)-15+"O");
			else
				xfrInfo = "Xfr last "+remoteNumChannelsXfr;
		
		Rect xfrRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(xfrInfo+"_", 0, xfrInfo.length()+1, xfrRect);

		String xfrRateInfo = "@ 00000Hz 00 reSyncs";
		Rect xfrRateRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(xfrRateInfo+"_", 0, xfrRateInfo.length()+1, xfrRateRect);		
		
		offsetPaint.setAntiAlias(savedAntiAlias);
		offsetPaint.setTypeface(savedTypeface);
		offsetPaint.setTextSize(savedTextSize);

		float remoteAt = lgPanelLeftMargin_f + 10.f;
		xfrRateAt = lgPanelRightMargin_f - 20.f - xfrRateRect.width();
		float xfrAt = xfrRateAt - xfrRect.width();
		lgLabelAt = (remoteAt+remoteRect.width() + xfrAt)*0.5f;
		offsetPaint.setAntiAlias(true);
		offsetPaint.setTypeface(Typeface.MONOSPACE);
		offsetPaint.setTextSize(offsetPaint.getTextSize()*0.8f);
		viCanvas.drawText(remoteInfo, remoteAt, lgPanelTopMargin_f/2.f+remoteRect.height()/2.f, offsetPaint);
		viCanvas.drawText(xfrInfo, xfrAt, lgPanelTopMargin_f/2.f+xfrRect.height()/2.f, offsetPaint);

		offsetPaint.setAntiAlias(savedAntiAlias);
		offsetPaint.setTypeface(savedTypeface);
		offsetPaint.setTextSize(savedTextSize);

		offsetPaint.setTextSize(prevTextSize);
	
		return vImage;
		}// end of createViewImage()

	private void updateTitle(Canvas viCanvas, Paint offsetPaint)
		{
		// label the channel being displayed 
	
		int numReSyncs = remoteAcquisitionFragment.getNumReSyncs();
		offsetPaint.setColor(Color.GREEN);
	
		float prevTextSize = offsetPaint.getTextSize();
		
		int lgOffset = (showAbsChan-2)/32;
		int chanOffset = showAbsChan-2 - lgOffset*32;
		String lgLabel = "Chan"+(showAbsChan+1);
		if ((remoteNumChannels-2)/32 != lgOffset)
			lgLabel = "ABCDEFGH".substring(lgOffset, lgOffset+1) + (chanOffset+1);
		else if ((chanOffset >= 0) && (chanOffset < 8))
				lgLabel = "Ex" + (chanOffset+1);
		else if ((chanOffset >= 8) && (chanOffset < 15))
				lgLabel = "Sn" + (chanOffset-8+1);
		else
			lgLabel = "O" + (chanOffset-15+1);
		Rect lgLabelRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(lgLabel, 0, lgLabel.length(), lgLabelRect);
			float 	electrodeCircleRadius = 15.f;
			offsetPaint.setStrokeWidth(0.0f);
		
		// radius is half height or width of label, whichever is bigger
		electrodeCircleRadius = ((lgLabelRect.width()>lgLabelRect.height())?lgLabelRect.width():lgLabelRect.height())/2.f + 2.f;
				
		// draw label outline oval

		// define enclosing rectangle (left, top, right, bottom)
		// show remote info in the upper left corner

		boolean savedAntiAlias = offsetPaint.isAntiAlias();
		Typeface savedTypeface = offsetPaint.getTypeface();
		float savedTextSize = offsetPaint.getTextSize();

		offsetPaint.setAntiAlias(true);
		offsetPaint.setTypeface(Typeface.MONOSPACE);
		offsetPaint.setTextSize(offsetPaint.getTextSize()*0.8f);

		// show transfer info in the upper right corner

		float bytesPerMsec = remoteAcquisitionFragment.getBytesPerMsec();
		int throughPut = 0;
		if ((bytesPerMsec > 1.) && (remoteNumChannelsXfr > 0))
		throughPut = (int)((bytesPerMsec*1000.f)/((float)(remoteNumChannelsXfr*3)));

		// right justify the throughput number
		
		String xfrRateInfo;
		if (throughPut > 9999)
			xfrRateInfo = "@ "+throughPut+"Hz "+numReSyncs+" reSyncs";
		else if (throughPut > 999)
			xfrRateInfo = "@  "+throughPut+"Hz "+numReSyncs+" reSyncs";
		else if (throughPut < 99)
			xfrRateInfo = "@   "+throughPut+"Hz "+numReSyncs+" reSyncs";
		else
			xfrRateInfo = "@    "+throughPut+"Hz "+numReSyncs+" reSyncs";

		Rect xfrRateRect = new Rect(0, 0, 1, 1);
		offsetPaint.getTextBounds(xfrRateInfo, 0, xfrRateInfo.length(), xfrRateRect);
		
		offsetPaint.setAntiAlias(savedAntiAlias);
		offsetPaint.setTypeface(savedTypeface);
		offsetPaint.setTextSize(savedTextSize);

		offsetPaint.setColor(Color.GREEN);
		offsetPaint.setStyle(Paint.Style.FILL);
		viCanvas.drawCircle(lgLabelAt, lgPanelTopMargin_f/2.f, electrodeCircleRadius, offsetPaint);

		offsetPaint.setColor(Color.BLACK);
		offsetPaint.setStyle(Paint.Style.STROKE);

		viCanvas.drawText(lgLabel, lgLabelAt-lgLabelRect.width()/2.f, lgPanelTopMargin_f/2.f+lgLabelRect.height()/2.f, offsetPaint);

		offsetPaint.setAntiAlias(true);
		offsetPaint.setTypeface(Typeface.MONOSPACE);
		offsetPaint.setTextSize(offsetPaint.getTextSize()*0.8f);

		// if throughput is low, make rate background yellow
		if (throughPut < (remoteSampleRate/10)*9)
			{
			offsetPaint.setColor(Color.YELLOW);
			offsetPaint.setStyle(Paint.Style.FILL);

			viCanvas.drawRect(xfrRateAt, lgPanelTopMargin_f/2.f-xfrRateRect.height()/2.f, xfrRateAt+xfrRateRect.width(),
				lgPanelTopMargin_f/2.f+xfrRateRect.height()/2.f, offsetPaint);

			offsetPaint.setColor(Color.BLACK);
			offsetPaint.setStyle(Paint.Style.STROKE);
			}

		viCanvas.drawText(xfrRateInfo, xfrRateAt, lgPanelTopMargin_f/2.f+xfrRateRect.height()/2.f, offsetPaint);

		offsetPaint.setAntiAlias(savedAntiAlias);
		offsetPaint.setTypeface(savedTypeface);
		offsetPaint.setTextSize(savedTextSize);

		offsetPaint.setTextSize(prevTextSize);

		return;
		}// updateTitle()
	
	public void newAcquisitionSamples(int cycleNumNow, int seamNow)
		{
		/*
		 *  called whenever a new buffer of data moves the "ring buffer" pointer
		 */
		if (newSamplesAvailableHandler != null)
			if (!stopRequested)
				{
				newSamplesAvailableHandler.sendMessage(newSamplesAvailableHandler.obtainMessage(1, cycleNumNow, seamNow, 0));
				}
		}

	public void onRestoreInstanceState(Bundle inState)
		{
		if (inState != null)
			{
			Set<String> keys = inState.keySet();

			if (keys.contains("slv_stopRequested"))
				stopRequested = inState.getBoolean("slv_stopRequested");
			if (keys.contains("slv_lastCycleNum"))
				lastCycleNum = inState.getInt("slv_lastCycleNum");

			if (keys.contains("slv_lastSeam"))
				lastSeam = inState.getInt("slv_lastSeam");
			}
		}

	public void onSaveInstanceState(Bundle outState)
		{
		remoteAcquisitionFragment.removeAcquisitionSamplesListener(UpdateViewImage.this);

		if (newSamplesAvailableHandler != null)
			newSamplesAvailableHandler.removeCallbacksAndMessages(null);
		newSamplesAvailableHandler = null;
				
		outState.putInt("slv_lastCycleNum",  lastCycleNum);
		outState.putInt("slv_lastSeam",  lastSeam);
		outState.putBoolean("slv_stopRequested", stopRequested);
		}

	public void resumeXfrUpdates()
		{
		samplePointsIndex = 0;
		currentSamplePointsIndex = samplePointsIndex;
		firstPassPlot = true;
		lastPlotPointsIndex = 0;
		lastTupleIndex = lastSeam - remoteNumChannels;
		}

	}// updateviewimage class
	
	// following added to satisfy lint
	
	public SingleLeadView(Context context)
		{
	    super(context);
		}
	
	public SingleLeadView(Context context, AttributeSet attrs)
		{
	    super(context, attrs);
		}
	
	}// singleleadview class