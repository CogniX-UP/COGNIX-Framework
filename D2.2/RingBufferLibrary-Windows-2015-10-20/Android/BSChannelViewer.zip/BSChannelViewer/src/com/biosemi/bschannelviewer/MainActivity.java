package com.biosemi.bschannelviewer;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

@TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
public class MainActivity extends Activity
	{
	private String	ipAddrString;
	private String	portString;
	private AlertDialog	configAlertDialog;
	private Button button32Chan;
	private Button buttonAllChan;
	private PopupWindow	helpPopupWindow;
	private TextView	tv;
	private String	version="2015-06-06";

	@Override
	protected void onCreate(Bundle savedInstanceState)
		{
		super.onCreate(savedInstanceState);

	    getWindow().requestFeature(Window.FEATURE_ACTION_BAR);	// make sure there is an action bar
	    
	    getActionBar().setDisplayHomeAsUpEnabled(true);
	
		setContentView(R.layout.activity_main);

	    ((TextView)findViewById(R.id.version)).setText("Version "+version);
	    
	    if ((ipAddrString != null) && (ipAddrString.length() > 0))
	    	tv.setText("Remote sample server is "+ipAddrString+", port "+portString);
		
		
		SharedPreferences preferences = getSharedPreferences("BSChannelViewer", MODE_PRIVATE);
	    String ipAddrField = preferences.getString("ipAddr", "");
	    if ((ipAddrField != null) && (ipAddrField.length() > 0) && !ipAddrField.startsWith(" "))
			{
	    	int spacex = ipAddrField.indexOf(' ');
	    	if (spacex >= 0)
				{// space starts a comment - drop comment
	    		ipAddrString = ipAddrField.substring(0, spacex);
	    		// android often adds a period before a space so drop any trailing period also
	    		if (ipAddrString.endsWith("."))
	    			ipAddrString = ipAddrString.substring(0, ipAddrString.length()-1);
				}
	    	else
	    		ipAddrString = ipAddrField;
			}

	    String portField = preferences.getString("port", "3113");
	    if ((portField != null) && (portField.length() > 0) && !portField.startsWith(" "))
    		portString = portField;

	    tv = (TextView)findViewById(R.id.remote_addr);
	    if ((ipAddrString != null) && (ipAddrString.length() > 0))
	    	tv.setText("Remote sample server is "+ipAddrString+", port "+portString);
	    else
	    	tv.setText("Remote sample server IPAddress is NOT SET");
	    
	    button32Chan = (Button) findViewById(R.id.button_32_channels);	    
    	button32Chan.setText("Connect in 32 channel mode");
	    button32Chan.setOnClickListener(new OnClickListener()
    		{
    		@Override
    		public void onClick(View v)
    			{
    			if ((ipAddrString == null) || (ipAddrString.length() == 0))
    				displayConfigDialog();
    			else
    				linkToAcquisitionControlActivity(32);
    			}
    		});

	    buttonAllChan = (Button) findViewById(R.id.button_all_channels);	    
    	buttonAllChan.setText("Connect in all channel mode");
	    buttonAllChan.setOnClickListener(new OnClickListener()
    		{
    		@Override
    		public void onClick(View v)
    			{
    			if ((ipAddrString == null) || (ipAddrString.length() == 0))
    				displayConfigDialog();
    			else
    				linkToAcquisitionControlActivity(0);
    			}
    		});
		}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
		{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
		}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
		{
		// Handle item selection
		switch (item.getItemId())
    		{
    		case R.id.configure:
    			displayConfigDialog();
    			return true;

    		case R.id.main_help:
    			if (helpPopupWindow == null)
    				displayHelp(R.string.activity_main_help_strings);
        		else
        			{
        			helpPopupWindow.dismiss();
        			helpPopupWindow = null;
        			}
    			return true;

    		case android.R.id.home:
    			System.exit(0);				// frees all application resources
    			return true;
			
    		default:
    			return super.onOptionsItemSelected(item);
    		}
		}

	public void displayConfigDialog()
		{
		LayoutInflater inflater = LayoutInflater.from(getBaseContext());
		final View inflatedConfigView = inflater.inflate(R.layout.activity_main_config_layout, null);
		final View configScrollView = inflatedConfigView.findViewById(R.id.activity_main_config_scroll_view);
	
		// find the config fields and set the current values

		final float densityScale = getResources().getDisplayMetrics().density;

		// ipaddr
		TextView promptText = (TextView) inflatedConfigView.findViewById(R.id.config_ipaddr);
		EditText editText = (EditText) inflatedConfigView.findViewById(R.id.config_ipaddr_edit);
		
		promptText.setTextSize((densityScale>1.1f)?12.f:18.f);
		editText.setTextSize((densityScale>1.1f)?12.f:18.f);
			
		SharedPreferences preferences = getSharedPreferences("BSChannelViewer", MODE_PRIVATE);
	    String editField = preferences.getString("ipAddr", "127.0.0.1");
		editText.setText(editField);

		// port
		promptText = (TextView) inflatedConfigView.findViewById(R.id.config_port);
		editText = (EditText) inflatedConfigView.findViewById(R.id.config_port_edit);

		promptText.setTextSize((densityScale>1.1f)?12.f:18.f);
		editText.setTextSize((densityScale>1.1f)?12.f:18.f);
			
	    editField = preferences.getString("port", "3113");
		editText.setText(editField);

		// connection timeout
		promptText = (TextView) inflatedConfigView.findViewById(R.id.config_connection_timeout);
		editText = (EditText) inflatedConfigView.findViewById(R.id.config_connection_timeout_edit);

		promptText.setTextSize((densityScale>1.1f)?12.f:18.f);
		editText.setTextSize((densityScale>1.1f)?12.f:18.f);
			
	    editField = preferences.getString("serverConnectionTimeout", "10");
		editText.setText(editField);

		// transmission timeout
		promptText = (TextView) inflatedConfigView.findViewById(R.id.config_transmission_timeout);
		editText = (EditText) inflatedConfigView.findViewById(R.id.config_transmission_timeout_edit);

		promptText.setTextSize((densityScale>1.1f)?12.f:18.f);
		editText.setTextSize((densityScale>1.1f)?12.f:18.f);
			
	    editField = preferences.getString("serverTransmissionTimeout", "5");
		editText.setText(editField);

		configAlertDialog = new AlertDialog.Builder(this)
			.setTitle("Configure")
			.setView(configScrollView)
			.setPositiveButton("Save", new DialogInterface.OnClickListener()
				{
				public void onClick(DialogInterface dialog, int whichButton)
    				{
					// get edited results

			    	SharedPreferences preferences = getSharedPreferences("BSChannelViewer", MODE_PRIVATE);
			    	SharedPreferences.Editor editor = preferences.edit();
					
			    	// ipaddr
					EditText editField = (EditText)inflatedConfigView.findViewById(R.id.config_ipaddr_edit);
					String editedField = editField.getText().toString().trim();
				    if ((editedField != null) && (editedField.length() > 0) && !editedField.startsWith(" "))
		    			{
				    	int spacex = editedField.indexOf(' ');
				    	if (spacex >= 0)
		    				{// space starts a comment - drop comment
				    		ipAddrString = editedField.substring(0, spacex);
				    		// android often adds a period before a space so drop any trailing period also
				    		if (ipAddrString.endsWith("."))
				    			ipAddrString = ipAddrString.substring(0, ipAddrString.length()-1);
		    				}
				    	else
				    		ipAddrString = editedField;

				    	editor.putString("ipAddr", editedField);
		    			}

				    // port
				    editField = (EditText)inflatedConfigView.findViewById(R.id.config_port_edit);
					editedField = editField.getText().toString().trim();
				    if ((editedField != null) && (editedField.length() > 0) && !editedField.startsWith(" "))
		    			{
				    	portString = editedField;
				    	
				    	editor.putString("port", editedField);
		    			}
				    
				    if ((ipAddrString != null) && (ipAddrString.length() > 0))
				    	tv.setText("Remote server is "+ipAddrString+", port "+portString);

				    // connection timeout
					editField = (EditText)inflatedConfigView.findViewById(R.id.config_connection_timeout_edit);
					editedField = editField.getText().toString().trim();
				    if ((editedField != null) && (editedField.length() > 0) && !editedField.startsWith(" "))
		    			{
				    	editor.putString("serverConnectionTimeout", editedField);
		    			}

				    // transmission timeout
					editField = (EditText)inflatedConfigView.findViewById(R.id.config_transmission_timeout_edit);
					editedField = editField.getText().toString().trim();
				    if ((editedField != null) && (editedField.length() > 0) && !editedField.startsWith(" "))
		    			{
				    	editor.putString("serverTransmissionTimeout", editedField);
		    			}
				    
				    // commit all edited fields
			    	editor.commit();
			    	
					configAlertDialog.dismiss();
					configAlertDialog = null;
    				}
				})
			.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
				{
				public void onClick(DialogInterface dialog, int whichButton)
    				{
					configAlertDialog.dismiss();
					configAlertDialog = null;
    				}
				})
			.create();

		configAlertDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
			{
			@Override
			public void onDismiss(DialogInterface dialog)
				{
				configAlertDialog = null;
				}
			});
		configAlertDialog.show();
		}

	public void linkToAcquisitionControlActivity(int numChannels2Request)
		{
		Bundle bundle = new Bundle();
		bundle.putString("ipAddrString", ipAddrString);
		bundle.putString("portString", portString);
		bundle.putInt("num_channels_to_request", numChannels2Request);

		Intent intent = new Intent(this.getBaseContext(),
				AcquisitionControlActivity.class);

		intent.putExtras(bundle);

		this.startActivityForResult(intent, 0);
		}

	private void displayHelp(int mTextResourceId)
		{
		if (mTextResourceId <= 0) mTextResourceId = R.string.no_help_available;

		LayoutInflater inflater = LayoutInflater.from(this);
		final View inflatedHelpView = inflater.inflate(R.layout.activity_main_help_layout, null);

		final TextView textView = (TextView) inflatedHelpView.findViewById (R.id.activity_main_topic_text);
		textView.setMovementMethod (LinkMovementMethod.getInstance());

		final float densityScale = getResources().getDisplayMetrics().density;
		textView.setTextSize((densityScale>1.1f)?12.f:18.f);
		textView.setText (Html.fromHtml(getString(mTextResourceId), new Html.ImageGetter()
    		{
			@Override
			public Drawable getDrawable(String source)
        		{
				int id;

				if (source.equals("configure64/"))
					id = R.drawable.configure64;
				else if (source.equals("graph3/"))
					id = R.drawable.graph3;
				else
					return null;
				Bitmap fgBitmap = BitmapFactory.decodeResource(getResources(), id);
        	
				Bitmap.Config conf = Bitmap.Config.ARGB_8888; // see other conf types
				Bitmap bgBitmap = Bitmap.createBitmap(fgBitmap.getWidth(), fgBitmap.getHeight(), conf); // this creates a MUTABLE bitmap
				Canvas bgCanvas = new Canvas(bgBitmap);
				bgCanvas.drawColor(Color.BLACK);
        	        	
				Bitmap mergedBitmap = Bitmap.createBitmap(fgBitmap.getWidth(), fgBitmap.getHeight(), conf); // this creates a MUTABLE bitmap
				Canvas mergedCanvas = new Canvas(mergedBitmap);
				mergedCanvas.drawBitmap(bgBitmap, new Matrix(), null);
				mergedCanvas.drawBitmap(fgBitmap, new Matrix(), null);
				Drawable mergedDrawable = new BitmapDrawable(getResources(), mergedBitmap);
				mergedDrawable.setBounds(0, 0, 32, 32);
        	
				bgBitmap.recycle();
				fgBitmap.recycle();
        	
				return mergedDrawable;
        		}
    		}, null));    		

		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		int height = size.y;
		helpPopupWindow = new PopupWindow(inflatedHelpView, (width*2)/3, (height*2)/3, true);
		helpPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener()
			{
			@Override
			public void onDismiss()
				{
				helpPopupWindow = null;
				}
			});
	
		inflatedHelpView.setOnTouchListener(new View.OnTouchListener()
			{
			@Override
			public boolean onTouch(View v, MotionEvent event)
				{
				if (helpPopupWindow != null)
					{
					helpPopupWindow.dismiss();
					helpPopupWindow = null;
					}
				return true;
				}
			});

		helpPopupWindow.setOutsideTouchable(true);

		LinearLayout mainLayout = new LinearLayout(this);
		helpPopupWindow.showAtLocation(mainLayout, Gravity.CENTER, 10, 10);
		}
	}